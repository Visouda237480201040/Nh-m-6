// ===== Danh mục cố định =====
// 18 tỉnh / thành của Lào (index được lưu trong hồ sơ học sinh)
const PROVINCES = [
  { vi: 'Thủ đô Viêng Chăn', lo: 'ນະຄອນຫຼວງວຽງຈັນ' },
  { vi: 'Viêng Chăn', lo: 'ແຂວງວຽງຈັນ' },
  { vi: 'Luông Pha Băng', lo: 'ຫຼວງພະບາງ' },
  { vi: 'Savannakhet', lo: 'ສະຫວັນນະເຂດ' },
  { vi: 'Chămpasắc', lo: 'ຈຳປາສັກ' },
  { vi: 'Xiêng Khoảng', lo: 'ຊຽງຂວາງ' },
  { vi: 'Khăm Muộn', lo: 'ຄຳມ່ວນ' },
  { vi: 'Bôlykhămxay', lo: 'ບໍລິຄຳໄຊ' },
  { vi: 'U Đôm Xay', lo: 'ອຸດົມໄຊ' },
  { vi: 'Salavan', lo: 'ສາລະວັນ' },
  { vi: 'Hủa Phăn', lo: 'ຫົວພັນ' },
  { vi: 'Attapư', lo: 'ອັດຕະປື' },
  { vi: 'Sê Kông', lo: 'ເຊກອງ' },
  { vi: 'Bò Kẹo', lo: 'ບໍ່ແກ້ວ' },
  { vi: 'Luông Nặm Tha', lo: 'ຫຼວງນ້ຳທາ' },
  { vi: 'Phôngsalỳ', lo: 'ຜົ້ງສາລີ' },
  { vi: 'Xaynhabuly', lo: 'ໄຊຍະບູລີ' },
  { vi: 'Xaysômbun', lo: 'ໄຊສົມບູນ' },
];

const ETHNICS = [
  { vi: 'Lào', lo: 'ລາວ' },
  { vi: 'Khơ Mú', lo: 'ຂະມຸ' },
  { vi: "H'Mông", lo: 'ມົ້ງ' },
  { vi: 'Phu Thái', lo: 'ຜູ້ໄທ' },
  { vi: 'Lự', lo: 'ລື້' },
  { vi: 'Tày', lo: 'ໄຕ' },
  { vi: 'Akha', lo: 'ອາຄ່າ' },
  { vi: 'Khác', lo: 'ອື່ນໆ' },
];

const SUBJECTS = [
  { id: 'lao', vi: 'Ngữ văn Lào', lo: 'ພາສາລາວ-ວັນນະຄະດີ', color: '#c2410c' },
  { id: 'math', vi: 'Toán', lo: 'ຄະນິດສາດ', color: '#1d4ed8' },
  { id: 'phys', vi: 'Vật lý', lo: 'ຟີຊິກສາດ', color: '#7c3aed' },
  { id: 'chem', vi: 'Hóa học', lo: 'ເຄມີສາດ', color: '#0f766e' },
  { id: 'bio', vi: 'Sinh học', lo: 'ຊີວະສາດ', color: '#15803d' },
  { id: 'hist', vi: 'Lịch sử', lo: 'ປະຫວັດສາດ', color: '#a16207' },
  { id: 'geo', vi: 'Địa lý', lo: 'ພູມສາດ', color: '#0369a1' },
  { id: 'eng', vi: 'Tiếng Anh', lo: 'ພາສາອັງກິດ', color: '#be123c' },
  { id: 'civ', vi: 'Giáo dục công dân', lo: 'ສຶກສາພົນລະເມືອງ', color: '#4d7c0f' },
  { id: 'it', vi: 'Tin học', lo: 'ໄອທີ', color: '#334155' },
  { id: 'pe', vi: 'Thể dục', lo: 'ພະລະສຶກສາ', color: '#b45309' },
];

const DEGREES = [
  { vi: 'Cao đẳng sư phạm', lo: 'ຊັ້ນສູງຄູ' },
  { vi: 'Cử nhân', lo: 'ປະລິນຍາຕີ' },
  { vi: 'Thạc sĩ', lo: 'ປະລິນຍາໂທ' },
  { vi: 'Tiến sĩ', lo: 'ປະລິນຍາເອກ' },
];

// Hệ phổ thông Lào: tiểu học 5 năm (P1–P5), trung học cơ sở 4 năm (M1–M4), trung học phổ thông 3 năm (M5–M7)
const GRADES = [1, 2, 3, 4, 5, 6, 7];
const DAYS = [1, 2, 3, 4, 5];
const PERIODS = [1, 2, 3, 4, 5, 6];

// Quyền theo vai trò: quản lý chọn cho từng tài khoản được dùng những chức năng nào
const ROLE_PERMS = {
  admin: ['dashboard', 'students', 'teachers', 'classes', 'grades', 'attendance', 'fees', 'timetable', 'accounts', 'settings'],
  teacher: ['tschedule', 'tclasses', 'attendance', 'grades'],
  student: ['sclass', 'sschedule', 'sattendance', 'sgrades', 'sfees'],
};
const EMAIL_DOMAIN = 'dokchampa.edu.la';

const loc = (o) => (o ? o[LANG] || o.vi : '');
const subjectById = (id) => SUBJECTS.find((s) => s.id === id);

// ===== Dữ liệu ban đầu =====
// Không có học sinh / giáo viên mẫu: quản lý tự thêm trên web.
// Chỉ tạo sẵn khung lớp M1–M7, thời khóa biểu theo môn, lịch sự kiện và 1 tài khoản quản lý.
const pad = (n, w = 2) => String(n).padStart(w, '0');
const isoDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

// Phạm vi id của học sinh / giáo viên mẫu ở phiên bản trước (để xóa khi nâng cấp dữ liệu cũ)
const OLD_SAMPLE = { students: 105, teachers: 14 };

function defaultTimetable(ci) {
  const weekly = ['lao', 'lao', 'lao', 'lao', 'math', 'math', 'math', 'math', 'phys', 'phys', 'chem', 'chem', 'bio', 'bio', 'hist', 'hist', 'geo', 'geo', 'eng', 'eng', 'eng', 'civ', 'it', 'it', 'pe', 'pe', 'lao', 'math', 'eng', 'civ'];
  const grid = {};
  let idx = ci * 7;
  DAYS.forEach((d) => PERIODS.forEach((p) => { grid[`${d}-${p}`] = weekly[idx++ % weekly.length]; }));
  return grid;
}

function createSeed() {
  const classDefs = [[1, 1], [1, 2], [2, 1], [2, 2], [3, 1], [4, 1], [5, 1], [6, 1], [7, 1]];
  const classes = classDefs.map(([g, n], i) => ({
    id: 'c' + (i + 1),
    name: `M${g}/${n}`,
    grade: g,
    homeroomId: '',
    room: `${g <= 4 ? 'A' : 'B'}${100 + i + 1}`,
    teachers: {},
  }));
  const timetable = {};
  classes.forEach((c, ci) => { timetable[c.id] = defaultTimetable(ci); });

  const settings = {
    nameVi: 'Trường Phổ thông Dok Champa',
    nameLo: 'ໂຮງຮຽນມັດທະຍົມສົມບູນ ດອກຈຳປາ',
    address: 'Bản Phôn Xay, huyện Xaysettha, Thủ đô Viêng Chăn',
    principal: '',
    phone: '',
    year: '2026 – 2027',
    feeLower: 1500000,
    feeUpper: 2000000,
  };

  const events = [
    { id: 'e1', date: '2026-10-07', name: 'Ngày Nhà giáo Lào / ວັນຄູແຫ່ງຊາດ' },
    { id: 'e2', date: '2026-11-24', name: 'Lễ hội That Luang / ບຸນທາດຫຼວງ' },
    { id: 'e3', date: '2026-12-02', name: 'Quốc khánh Lào / ວັນຊາດ 2 ທັນວາ' },
    { id: 'e4', date: '2027-04-14', name: 'Tết Bunpimay / ບຸນປີໃໝ່ລາວ' },
  ];

  const accounts = [
    { id: 'a1', email: `admin@${EMAIL_DOMAIN}`, pass: 'admin123', role: 'admin', refId: '', name: 'Admin', perms: ROLE_PERMS.admin.slice(), active: true, lastLogin: '' },
  ];

  return {
    version: 3,
    settings,
    accounts,
    teachers: [], classes, students: [], grades: {}, attendance: {}, payments: [], timetable, events,
    seq: { s: 0, t: 0, c: classes.length, p: 0, e: events.length, a: accounts.length },
  };
}
