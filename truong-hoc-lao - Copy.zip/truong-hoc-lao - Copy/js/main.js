'use strict';

// ===== Tiện ích =====
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const norm = (s) => String(s ?? '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/đ/g, 'd');

// ===== Lưu trữ =====
const STORE_KEY = 'dokchampa-school';
const PREF_KEY = 'dokchampa-prefs';
const AUTH_KEY = 'dokchampa-auth';

// Nâng cấp dữ liệu phiên bản cũ (v1, v2): xóa học sinh / giáo viên mẫu, giữ lại những gì người dùng tự thêm
function migrate(d) {
  if (d.version < 3) {
    const num = (id) => parseInt(String(id).slice(1), 10);
    const sampleS = new Set(d.students.filter((s) => num(s.id) <= OLD_SAMPLE.students).map((s) => s.id));
    const sampleT = new Set(d.teachers.filter((x) => num(x.id) <= OLD_SAMPLE.teachers).map((x) => x.id));
    d.students = d.students.filter((s) => !sampleS.has(s.id));
    d.teachers = d.teachers.filter((x) => !sampleT.has(x.id));
    Object.keys(d.grades || {}).forEach((k) => { if (sampleS.has(k.split('|')[0])) delete d.grades[k]; });
    Object.keys(d.attendance || {}).forEach((k) => {
      const rec = d.attendance[k];
      Object.keys(rec).forEach((sid) => { if (sampleS.has(sid)) delete rec[sid]; });
      if (!Object.keys(rec).length) delete d.attendance[k];
    });
    d.payments = (d.payments || []).filter((p) => !sampleS.has(p.studentId));
    d.classes.forEach((c) => {
      if (sampleT.has(c.homeroomId)) c.homeroomId = '';
      c.teachers = c.teachers || {};
      Object.keys(c.teachers).forEach((k) => { if (sampleT.has(c.teachers[k])) delete c.teachers[k]; });
    });
    if (!Array.isArray(d.accounts)) {
      const old = d.account || { pass: 'admin123' };
      d.accounts = [{ id: 'a1', email: `admin@${EMAIL_DOMAIN}`, pass: old.pass, role: 'admin', refId: '', name: 'Admin', perms: ROLE_PERMS.admin.slice(), active: true, lastLogin: '' }];
    }
    delete d.account;
    d.accounts = d.accounts.filter((a) => !(a.role === 'student' && sampleS.has(a.refId)) && !(a.role === 'teacher' && sampleT.has(a.refId)));
    if (!d.students.length) d.seq.s = 0;
    if (!d.teachers.length) d.seq.t = 0;
    if (!d.payments.length) d.seq.p = 0;
    d.version = 3;
  }
  // Luôn còn ít nhất 1 tài khoản quản lý để đăng nhập
  const idNum = (a) => parseInt(a.id.slice(1), 10) || 0;
  if (!d.accounts.some((a) => a.role === 'admin' && a.active && a.perms.includes('accounts'))) {
    const email = `admin@${EMAIL_DOMAIN}`;
    const existing = d.accounts.find((a) => a.email.toLowerCase() === email);
    if (existing) Object.assign(existing, { role: 'admin', refId: '', perms: ROLE_PERMS.admin.slice(), active: true });
    else d.accounts.push({ id: 'a' + (Math.max(0, ...d.accounts.map(idNum)) + 1), email, pass: 'admin123', role: 'admin', refId: '', name: 'Admin', perms: ROLE_PERMS.admin.slice(), active: true, lastLogin: '' });
  }
  d.seq.a = Math.max(d.seq.a || 0, ...d.accounts.map(idNum));
  return d;
}
const validDb = (d) => d && [1, 2, 3].includes(d.version) && Array.isArray(d.students) && Array.isArray(d.classes) && Array.isArray(d.teachers) && d.settings && d.seq;

function loadDb() {
  try {
    const raw = localStorage.getItem(STORE_KEY);
    if (raw) {
      const d = JSON.parse(raw);
      if (validDb(d)) return migrate(d);
    }
  } catch (e) { /* bỏ qua, dùng dữ liệu mẫu */ }
  return createSeed();
}

let db = loadDb();
function save() {
  try { localStorage.setItem(STORE_KEY, JSON.stringify(db)); } catch (e) { toast('localStorage error', 'error'); }
}
save();

const prefs = { lang: 'vi', theme: '' };
try { Object.assign(prefs, JSON.parse(localStorage.getItem(PREF_KEY)) || {}); } catch (e) { /* ignore */ }
function savePrefs() { try { localStorage.setItem(PREF_KEY, JSON.stringify(prefs)); } catch (e) { /* ignore */ } }
LANG = prefs.lang === 'lo' ? 'lo' : 'vi';

// ===== Phiên đăng nhập & phân quyền =====
let memAuth = '';
const authId = () => { try { return sessionStorage.getItem(AUTH_KEY) || ''; } catch (e) { return memAuth; } };
const setAuth = (id) => { memAuth = id; try { id ? sessionStorage.setItem(AUTH_KEY, id) : sessionStorage.removeItem(AUTH_KEY); } catch (e) { /* ignore */ } };
function me() {
  const a = db.accounts.find((x) => x.id === authId());
  return a && a.active ? a : null;
}
const isLoggedIn = () => !!me();
const can = (perm) => { const u = me(); return !!u && u.perms.includes(perm); };
const myPerson = () => {
  const u = me();
  if (!u) return null;
  return u.role === 'teacher' ? teacherById(u.refId) : u.role === 'student' ? studentById(u.refId) : null;
};
const accountOf = (role, refId) => db.accounts.find((a) => a.role === role && a.refId === refId);
function displayName(a) {
  const p = a.role === 'teacher' ? teacherById(a.refId) : a.role === 'student' ? studentById(a.refId) : null;
  return p ? p.name : a.name || a.email;
}

// ===== Định dạng =====
const fmtNum = (n) => Number(n || 0).toLocaleString(LANG === 'vi' ? 'vi-VN' : 'en-US');
const fmtKip = (n) => `${fmtNum(n)} ₭`;
const fmtDate = (iso) => { if (!iso) return ''; const [y, m, d] = iso.split('-'); return `${d}/${m}/${y}`; };
const todayIso = () => isoDate(new Date());
const fmtScore = (v) => (v == null ? '' : v.toFixed(1));
const pct = (v) => (v == null ? '—' : `${Math.round(v * 100)}%`);

// ===== Tra cứu =====
const classById = (id) => db.classes.find((c) => c.id === id);
const teacherById = (id) => db.teachers.find((x) => x.id === id);
const studentById = (id) => db.students.find((s) => s.id === id);
const byName = (a, b) => a.name.localeCompare(b.name);
const className = (c) => (c ? (LANG === 'lo' ? c.name.replace(/^M/, 'ມ.') : c.name) : '—');
const gradeLabel = (g) => (LANG === 'lo' ? 'ມ.' : 'M') + g;
const genderLabel = (g) => t(g === 'F' ? 'c.female' : 'c.male');
const schoolName = () => (LANG === 'lo' ? db.settings.nameLo : db.settings.nameVi) || db.settings.nameVi;
const sortedClasses = () => db.classes.slice().sort((a, b) => a.grade - b.grade || a.name.localeCompare(b.name, undefined, { numeric: true }));
const studentsOf = (cid) => db.students.filter((s) => s.classId === cid).sort(byName);
const nextId = (k) => k + ++db.seq[k];
const initials = (name) => name.split(/\s+/).map((w) => w[0]).slice(0, 2).join('').toUpperCase();
const classOrder = (s) => { const c = classById(s.classId); return c ? c.grade * 100 + parseInt(c.name.split('/')[1] || 0, 10) : 9999; };

function classOptions(sel, withAll, list = sortedClasses()) {
  return (withAll ? `<option value="">${t('c.class')}: ${t('c.all')}</option>` : '') +
    list.map((c) => `<option value="${c.id}"${c.id === sel ? ' selected' : ''}>${esc(className(c))}</option>`).join('');
}

// Phạm vi dữ liệu: giáo viên chỉ thấy lớp được phân công / chủ nhiệm, và chỉ nhập điểm môn mình dạy
function myClasses() {
  const u = me();
  if (!u || u.role !== 'teacher') return sortedClasses();
  return sortedClasses().filter((c) => c.homeroomId === u.refId || Object.values(c.teachers || {}).includes(u.refId));
}
function mySubjects(cid) {
  const u = me();
  if (!u || u.role !== 'teacher') return SUBJECTS;
  const c = classById(cid);
  return SUBJECTS.filter((s) => c && c.teachers && c.teachers[s.id] === u.refId);
}
const teacherFor = (sub, cid) => { const c = classById(cid); return c && c.teachers ? teacherById(c.teachers[sub]) : null; };
const PERIOD_TIME = ['07:30', '08:25', '09:30', '10:25', '13:30', '14:25'];
const todayDow = () => new Date().getDay(); // 1 = Thứ Hai … 5 = Thứ Sáu
function lessonsOfTeacher(tid) {
  const out = [];
  db.classes.forEach((c) => {
    Object.entries(db.timetable[c.id] || {}).forEach(([slot, sub]) => {
      if (sub && c.teachers && c.teachers[sub] === tid) {
        const [d, p] = slot.split('-').map(Number);
        out.push({ c, d, p, sub: subjectById(sub) });
      }
    });
  });
  return out.sort((a, b) => a.d - b.d || a.p - b.p);
}
const fmtDateTime = (iso) => { if (!iso) return ''; const d = new Date(iso); return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`; };
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const opts = (list, sel) => list.map((o) => `<option value="${esc(o.v)}"${String(o.v) === String(sel) ? ' selected' : ''}>${esc(o.l)}</option>`).join('');

// ===== Học phí =====
const feeOf = (s) => { const c = classById(s.classId); return !c ? 0 : c.grade <= 4 ? db.settings.feeLower : db.settings.feeUpper; };
const paidOf = (sid) => db.payments.reduce((a, p) => (p.studentId === sid ? a + p.amount : a), 0);
function feeInfo(s) {
  const req = feeOf(s), paid = paidOf(s.id), remain = Math.max(0, req - paid);
  const status = req > 0 && paid >= req ? 'paid' : paid > 0 ? 'partial' : 'unpaid';
  return { req, paid, remain, status };
}
const FEE_BADGE = { paid: ['good', 'fa-circle-check'], partial: ['warn', 'fa-circle-half-stroke'], unpaid: ['bad', 'fa-circle-exclamation'] };
const feeBadge = (st) => `<span class="badge ${FEE_BADGE[st][0]}"><i class="fa-solid ${FEE_BADGE[st][1]}"></i> ${t('fe.st.' + st)}</span>`;

// ===== Điểm số =====
const PARTS = ['oral', 't15', 'mid', 'final'];
const WEIGHT = { oral: 1, t15: 1, mid: 2, final: 3 };
const PART_LABEL = { oral: 'gr.oral', t15: 'gr.t15', mid: 'gr.mid', final: 'gr.final' };
const gradeRec = (sid, sub, sem) => db.grades[`${sid}|${sub}|${sem}`];
function avgOf(g) {
  if (!g) return null;
  let s = 0, w = 0;
  PARTS.forEach((p) => { if (g[p] != null) { s += g[p] * WEIGHT[p]; w += WEIGHT[p]; } });
  return w ? Math.round((s / w) * 10) / 10 : null;
}
function overallAvg(sid, sem) {
  const vals = SUBJECTS.map((s) => avgOf(gradeRec(sid, s.id, sem))).filter((v) => v != null);
  return vals.length ? Math.round((vals.reduce((a, b) => a + b, 0) / vals.length) * 10) / 10 : null;
}
function rankOf(avg) {
  if (avg == null) return null;
  if (avg >= 9) return { k: 'r.excellent', c: 'exc' };
  if (avg >= 8) return { k: 'r.good', c: 'good' };
  if (avg >= 6.5) return { k: 'r.fair', c: 'info' };
  if (avg >= 5) return { k: 'r.average', c: 'warn' };
  return { k: 'r.weak', c: 'bad' };
}
const rankBadge = (avg) => { const r = rankOf(avg); return r ? `<span class="badge ${r.c}">${t(r.k)}</span>` : '<span class="muted">—</span>'; };

// ===== Điểm danh =====
const ATT = [
  { k: 'P', l: 'at.present', c: 'good', i: 'fa-check' },
  { k: 'L', l: 'at.late', c: 'warn', i: 'fa-clock' },
  { k: 'E', l: 'at.excused', c: 'info', i: 'fa-envelope-open-text' },
  { k: 'A', l: 'at.absent', c: 'bad', i: 'fa-xmark' },
];
function attStats(sid) {
  const c = { P: 0, L: 0, E: 0, A: 0, total: 0 };
  for (const key in db.attendance) {
    const v = db.attendance[key][sid];
    if (v) { c[v]++; c.total++; }
  }
  c.rate = c.total ? (c.P + c.L) / c.total : null;
  return c;
}

// ===== Thành phần giao diện =====
function toast(msg, type = 'ok') {
  let box = $('#toasts');
  if (!box) { box = document.createElement('div'); box.id = 'toasts'; document.body.appendChild(box); }
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<i class="fa-solid ${type === 'error' ? 'fa-circle-exclamation' : 'fa-circle-check'}"></i><span></span>`;
  el.querySelector('span').textContent = msg;
  box.appendChild(el);
  setTimeout(() => el.classList.add('hide'), 2600);
  setTimeout(() => el.remove(), 3000);
}

function openModal({ title, body, foot = '', wide = false }) {
  closeModal();
  const m = document.createElement('div');
  m.className = 'modal-backdrop';
  m.innerHTML = `<div class="modal ${wide ? 'wide' : ''}" role="dialog" aria-modal="true">
    <div class="modal-head"><h3>${esc(title)}</h3><button class="icon-btn" data-close aria-label="${t('c.close')}"><i class="fa-solid fa-xmark"></i></button></div>
    <div class="modal-body">${body}</div>
    ${foot ? `<div class="modal-foot">${foot}</div>` : ''}
  </div>`;
  m.addEventListener('click', (e) => { if (e.target === m || e.target.closest('[data-close]')) closeModal(); });
  document.body.appendChild(m);
  requestAnimationFrame(() => m.classList.add('show'));
  return m;
}
function closeModal() { $$('.modal-backdrop').forEach((m) => m.remove()); }

function fieldHtml(f, v) {
  const val = v ?? '';
  const req = f.required ? ' required' : '';
  const star = f.required ? ' <span class="req">*</span>' : '';
  let input;
  if (f.type === 'select') input = `<select name="${f.name}"${req}>${opts(f.options, val)}</select>`;
  else if (f.type === 'textarea') input = `<textarea name="${f.name}" rows="3">${esc(val)}</textarea>`;
  else input = `<input type="${f.type || 'text'}" name="${f.name}" value="${esc(val)}"${req}${f.attrs || ''}>`;
  return `<label class="field${f.full ? ' full' : ''}"><span>${esc(f.label)}${star}</span>${input}</label>`;
}

function formModal({ title, fields, values = {}, submitLabel, onSubmit, intro = '' }) {
  const m = openModal({
    title,
    body: `${intro}<form class="form-grid" novalidate>${fields.map((f) => fieldHtml(f, values[f.name])).join('')}<p class="form-error full" hidden></p></form>`,
    foot: `<button class="btn ghost" data-close>${t('c.cancel')}</button><button class="btn primary" data-submit><i class="fa-solid fa-check"></i> ${esc(submitLabel || t('c.save'))}</button>`,
  });
  const form = $('form', m);
  const err = $('.form-error', form);
  const submit = () => {
    const vals = {};
    let missing = false;
    fields.forEach((f) => {
      const el = form.elements[f.name];
      const v = el.value.trim();
      const bad = f.required && !v;
      el.classList.toggle('invalid', bad);
      if (bad) missing = true;
      vals[f.name] = f.type === 'number' ? (v === '' ? null : Number(v)) : v;
    });
    if (missing) { err.textContent = t('c.required'); err.hidden = false; return; }
    const res = onSubmit(vals);
    if (typeof res === 'string') { err.textContent = res; err.hidden = false; return; }
    closeModal();
  };
  $('[data-submit]', m).addEventListener('click', submit);
  form.addEventListener('submit', (e) => { e.preventDefault(); submit(); });
  form.addEventListener('keydown', (e) => { if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') { e.preventDefault(); submit(); } });
  setTimeout(() => { const first = form.querySelector('input, select'); if (first) first.focus(); }, 60);
  return m;
}

function confirmBox(msg, onYes) {
  const m = openModal({
    title: t('c.confirm'),
    body: `<div class="confirm"><i class="fa-solid fa-triangle-exclamation"></i><p>${esc(msg)}</p></div>`,
    foot: `<button class="btn ghost" data-close>${t('c.cancel')}</button><button class="btn danger" data-yes><i class="fa-solid fa-check"></i> ${t('c.confirm')}</button>`,
  });
  $('[data-yes]', m).addEventListener('click', () => { closeModal(); onYes(); });
}

function download(name, content, type) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement('a');
  a.href = url; a.download = name;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}
function downloadCsv(name, rows) {
  const csv = '﻿' + rows.map((r) => r.map((v) => `"${String(v ?? '').replace(/"/g, '""')}"`).join(',')).join('\r\n');
  download(name, csv, 'text/csv;charset=utf-8');
}

function printHtml(html) {
  $('#printArea').innerHTML = html;
  window.print();
}

// Tooltip dùng chung cho biểu đồ
const tip = document.createElement('div');
tip.className = 'tooltip';
document.body.appendChild(tip);
function showTip(el, x, y) {
  tip.textContent = el.dataset.tip;
  tip.classList.add('show');
  const r = tip.getBoundingClientRect();
  tip.style.left = Math.min(window.innerWidth - r.width - 8, Math.max(8, x - r.width / 2)) + 'px';
  tip.style.top = Math.max(8, y - r.height - 12) + 'px';
}
document.addEventListener('mousemove', (e) => {
  const el = e.target.closest && e.target.closest('[data-tip]');
  if (el) showTip(el, e.clientX, e.clientY); else tip.classList.remove('show');
});
document.addEventListener('focusin', (e) => {
  const el = e.target.closest && e.target.closest('[data-tip]');
  if (el) { const r = el.getBoundingClientRect(); showTip(el, r.left + r.width / 2, r.top); } else tip.classList.remove('show');
});

// ===== Giao diện: chủ đề =====
function applyTheme() {
  if (prefs.theme) document.documentElement.dataset.theme = prefs.theme;
  else delete document.documentElement.dataset.theme;
  document.documentElement.lang = LANG;
}
const isDark = () => prefs.theme === 'dark' || (!prefs.theme && window.matchMedia('(prefers-color-scheme: dark)').matches);

// ===== Khung ứng dụng =====
// Menu theo vai trò. Mỗi mục (trừ trang chủ) là một quyền mà quản lý bật / tắt cho từng tài khoản
const NAV = {
  admin: [
    ['dashboard', 'fa-gauge-high'],
    ['students', 'fa-user-graduate'],
    ['teachers', 'fa-chalkboard-user'],
    ['classes', 'fa-school'],
    ['grades', 'fa-star-half-stroke'],
    ['attendance', 'fa-clipboard-check'],
    ['fees', 'fa-money-bill-wave'],
    ['timetable', 'fa-calendar-days'],
    ['accounts', 'fa-user-shield'],
    ['settings', 'fa-gear'],
  ],
  teacher: [
    ['thome', 'fa-house'],
    ['tschedule', 'fa-calendar-week'],
    ['tclasses', 'fa-people-roof'],
    ['attendance', 'fa-clipboard-check'],
    ['grades', 'fa-star-half-stroke'],
  ],
  student: [
    ['shome', 'fa-house'],
    ['sclass', 'fa-people-roof'],
    ['sschedule', 'fa-calendar-days'],
    ['sattendance', 'fa-clipboard-check'],
    ['sgrades', 'fa-star-half-stroke'],
    ['sfees', 'fa-money-bill-wave'],
  ],
};
const ALWAYS = ['thome', 'shome', 'profile'];
const PERM_ICON = Object.fromEntries([...NAV.admin, ...NAV.teacher, ...NAV.student]);

function allowedNav() {
  const u = me();
  if (!u) return [];
  return NAV[u.role].filter(([k]) => ALWAYS.includes(k) || u.perms.includes(k));
}
const allowedPages = () => allowedNav().map(([k]) => k).concat('profile');

const langSwitch = () => `<div class="seg lang-seg" role="group" aria-label="Language">
  <button data-act="setLang" data-v="vi" class="${LANG === 'vi' ? 'on' : ''}">VI</button>
  <button data-act="setLang" data-v="lo" class="${LANG === 'lo' ? 'on' : ''}">ລາວ</button>
</div>`;

// Tài khoản quản lý mặc định (tài khoản giáo viên / học sinh do quản lý tự tạo)
const DEMO = [
  ['admin', `admin@${EMAIL_DOMAIN}`, 'admin123', 'fa-user-shield'],
];

function renderLogin() {
  document.title = `${t('login.title')} · ${schoolName()}`;
  $('#app').innerHTML = `
  <div class="login">
    <div class="login-flag" aria-hidden="true"><span></span><span></span><span></span></div>
    <form class="login-card" id="loginForm" novalidate>
      <div class="login-top">${langSwitch()}</div>
      <div class="login-logo"><i class="fa-solid fa-spa"></i></div>
      <h1>${esc(schoolName())}</h1>
      <p class="muted">${t('app.title')}</p>
      <label class="field"><span>${t('login.email')}</span><input name="user" type="email" autocomplete="username" placeholder="name@${EMAIL_DOMAIN}"></label>
      <label class="field"><span>${t('login.pass')}</span><input name="pass" type="password" autocomplete="current-password"></label>
      <p class="form-error" hidden></p>
      <button class="btn primary block" type="submit"><i class="fa-solid fa-right-to-bracket"></i> ${t('login.submit')}</button>
      <div class="demo">
        <span class="muted">${t('login.demo')}</span>
        <div class="demo-btns">${DEMO.map(([r, e, p, i]) => `<button type="button" class="btn sm ghost" data-act="fillDemo" data-e="${e}" data-p="${p}"><i class="fa-solid ${i}"></i> ${t('role.' + r)}</button>`).join('')}</div>
      </div>
    </form>
  </div>`;
  const f = $('#loginForm');
  f.addEventListener('submit', (e) => {
    e.preventDefault();
    const email = f.elements.user.value.trim().toLowerCase();
    const acc = db.accounts.find((a) => a.email.toLowerCase() === email && a.pass === f.elements.pass.value);
    const err = $('.form-error', f);
    if (!acc) { err.textContent = t('login.fail'); err.hidden = false; return; }
    if (!acc.active) { err.textContent = t('login.locked'); err.hidden = false; return; }
    acc.lastLogin = new Date().toISOString();
    save();
    setAuth(acc.id);
    history.replaceState(null, '', '#' + allowedPages()[0]);
    renderApp();
  });
  f.elements.user.focus();
}

function renderApp() {
  const u = me();
  if (!u) return renderLogin();
  document.title = `${t('app.short')} · ${schoolName()}`;
  const name = displayName(u);
  $('#app').innerHTML = `
  <div class="shell">
    <aside class="sidebar">
      <div class="brand">
        <div class="brand-logo"><i class="fa-solid fa-spa"></i></div>
        <div class="brand-text"><b>${esc(schoolName())}</b><small>${t('app.title')}</small></div>
      </div>
      <div class="role-tag role-${u.role}"><i class="fa-solid ${u.role === 'admin' ? 'fa-user-shield' : u.role === 'teacher' ? 'fa-chalkboard-user' : 'fa-user-graduate'}"></i> ${t('role.' + u.role)}</div>
      <nav class="nav">
        ${allowedNav().map(([k, i]) => `<a href="#${k}" data-page="${k}"><i class="fa-solid ${i}"></i><span>${t('nav.' + k)}</span></a>`).join('')}
        <a href="#profile" data-page="profile" class="nav-profile"><i class="fa-solid fa-id-badge"></i><span>${t('nav.profile')}</span></a>
      </nav>
      <div class="side-foot"><i class="fa-regular fa-calendar"></i> ${t('se.year')}: ${esc(db.settings.year)}</div>
    </aside>
    <div class="overlay" data-act="closeSide"></div>
    <main class="main">
      <header class="topbar">
        <button class="icon-btn menu-btn" data-act="openSide" aria-label="Menu"><i class="fa-solid fa-bars"></i></button>
        <h1 id="pageTitle"></h1>
        <div class="top-actions">
          ${langSwitch()}
          <button class="icon-btn" data-act="toggleTheme" aria-label="${t('se.theme')}"><i class="fa-solid ${isDark() ? 'fa-sun' : 'fa-moon'}"></i></button>
          <a class="user-chip" href="#profile"><span class="avatar ${u.role === 'admin' ? 'M' : (myPerson() || {}).gender || 'M'}">${esc(initials(name))}</span><div><b>${esc(name)}</b><small>${t('role.' + u.role)}</small></div></a>
          <button class="icon-btn" data-act="logout" aria-label="${t('login.logout')}" title="${t('login.logout')}"><i class="fa-solid fa-right-from-bracket"></i></button>
        </div>
      </header>
      <section id="view" class="view"></section>
    </main>
  </div>`;
  renderView();
}

let lastPage = '';
function currentPage() {
  const allowed = allowedPages();
  const p = location.hash.slice(1);
  if (allowed.includes(p)) return p;
  if (PAGES[p] && p !== lastPage) toast(t('c.noPerm'), 'error');
  return allowed[0];
}
function renderView() {
  if (!isLoggedIn()) return renderLogin();
  const view = $('#view');
  if (!view) return renderApp();
  const p = currentPage();
  $$('.nav a').forEach((a) => a.classList.toggle('active', a.dataset.page === p));
  $('#pageTitle').textContent = t('nav.' + p);
  view.innerHTML = PAGES[p]();
  document.body.classList.remove('side-open');
  if (p !== lastPage) window.scrollTo(0, 0);
  lastPage = p;
}
window.addEventListener('hashchange', renderView);

// ===== Trạng thái bộ lọc từng trang =====
const ui = {
  st: { q: '', cls: '', gender: '', page: 1 },
  tc: { q: '', sub: '' },
  fe: { q: '', cls: '', status: '', page: 1 },
  gr: { cls: '', sub: 'math', sem: '1', mode: 'entry' },
  at: { cls: '', date: todayIso() },
  tt: { cls: '', edit: false },
  acc: { q: '', role: '', page: 1 },
  sg: { sem: '1' },
};
const ensureClass = (o, list = sortedClasses()) => { if (!list.some((c) => c.id === o.cls)) o.cls = (list[0] || {}).id || ''; return o.cls; };
const PAGE_SIZE = 12;

function pager(total, page, act) {
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));
  if (pages <= 1) return '';
  let btns = '';
  for (let i = 1; i <= pages; i++) btns += `<button class="${i === page ? 'on' : ''}" data-act="${act}" data-p="${i}">${i}</button>`;
  return `<div class="pager"><span class="muted">${t('c.page')} ${page}${t('c.of')}${pages}</span>
    <div class="pager-btns"><button data-act="${act}" data-p="${page - 1}" ${page <= 1 ? 'disabled' : ''} aria-label="prev"><i class="fa-solid fa-chevron-left"></i></button>${btns}<button data-act="${act}" data-p="${page + 1}" ${page >= pages ? 'disabled' : ''} aria-label="next"><i class="fa-solid fa-chevron-right"></i></button></div></div>`;
}
const emptyRow = (cols) => `<tr><td colspan="${cols}" class="empty"><i class="fa-regular fa-folder-open"></i> ${t('c.noData')}</td></tr>`;
const pageHead = (title, sub, actions = '') => `<div class="page-head"><div><h2>${title}</h2>${sub ? `<p class="muted">${sub}</p>` : ''}</div><div class="head-actions">${actions}</div></div>`;
const rowActions = (kind, id) => `<div class="row-actions">
  ${kind === 'Student' ? `<button class="icon-btn sm" data-act="view${kind}" data-id="${id}" title="${t('c.view')}" aria-label="${t('c.view')}"><i class="fa-regular fa-eye"></i></button>` : ''}
  <button class="icon-btn sm" data-act="edit${kind}" data-id="${id}" title="${t('c.edit')}" aria-label="${t('c.edit')}"><i class="fa-regular fa-pen-to-square"></i></button>
  <button class="icon-btn sm danger" data-act="del${kind}" data-id="${id}" title="${t('c.delete')}" aria-label="${t('c.delete')}"><i class="fa-regular fa-trash-can"></i></button>
</div>`;
// Ô "tài khoản" trong bảng học sinh / giáo viên: đã có → xem email, chưa có → nút tạo (nếu có quyền)
function accountCell(role, refId) {
  const a = accountOf(role, refId);
  if (a) {
    const inner = `<span class="badge ${a.active ? 'good' : 'bad'}"><i class="fa-solid ${a.active ? 'fa-user-check' : 'fa-lock'}"></i> ${esc(a.email)}</span>`;
    return can('accounts') ? `<button class="plain" data-act="editAccount" data-id="${a.id}" title="${t('acc.editTitle')}">${inner}</button>` : inner;
  }
  return can('accounts')
    ? `<button class="btn sm ghost" data-act="newAccountFor" data-role="${role}" data-ref="${refId}"><i class="fa-solid fa-user-plus"></i> ${t('acc.createFor')}</button>`
    : `<span class="muted">${t('acc.noAccount')}</span>`;
}
const personCell = (p, sub) => `<div class="person"><span class="avatar ${p.gender}">${esc(initials(p.name))}</span><div><b>${esc(p.name)}</b><small>${sub}</small></div></div>`;

// ===== Các trang =====
const PAGES = {};

// ---------- Tổng quan ----------
PAGES.dashboard = () => {
  const S = db.students;
  const male = S.filter((s) => s.gender === 'M').length;
  const today = todayIso();

  let taken = 0, pres = 0, tot = 0;
  db.classes.forEach((c) => {
    const r = db.attendance[`${c.id}|${today}`];
    if (r && Object.keys(r).length) {
      taken++;
      Object.values(r).forEach((v) => { tot++; if (v === 'P' || v === 'L') pres++; });
    }
  });

  let exp = 0, col = 0;
  const cnt = { paid: 0, partial: 0, unpaid: 0 };
  S.forEach((s) => { const f = feeInfo(s); exp += f.req; col += Math.min(f.paid, f.req); cnt[f.status]++; });
  const feePct = exp ? Math.round((col / exp) * 100) : 0;

  const byGrade = GRADES.map((g) => {
    const cls = db.classes.filter((c) => c.grade === g);
    return { g, n: S.filter((s) => cls.some((c) => c.id === s.classId)).length, k: cls.length };
  });
  const max = Math.max(1, ...byGrade.map((x) => x.n));
  const niceMax = Math.ceil(max / 10) * 10 || 10;

  const top = S.map((s) => ({ s, a: overallAvg(s.id, 1) })).filter((x) => x.a != null).sort((a, b) => b.a - a.a).slice(0, 5);
  const events = db.events.filter((e) => e.date >= today).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 6);
  const lower = db.classes.filter((c) => c.grade <= 4).length;

  const tile = (icon, tone, label, value, sub, href) => `
    <a class="stat ${tone}" href="#${href}">
      <div class="stat-icon"><i class="fa-solid ${icon}"></i></div>
      <div><span class="stat-label">${label}</span><b class="stat-value">${value}</b><small>${sub}</small></div>
    </a>`;

  return `
  <div class="hero">
    <div><h2>${t('dash.welcome')}</h2><p>${esc(schoolName())} · ${t('dash.sub')} · ${fmtDate(today)}</p></div>
    <div class="hero-flag" aria-hidden="true"><span></span><span></span><span></span></div>
  </div>

  <div class="stats">
    ${tile('fa-user-graduate', 't1', t('dash.students'), fmtNum(S.length), `${t('c.male')} ${male} · ${t('c.female')} ${S.length - male}`, 'students')}
    ${tile('fa-chalkboard-user', 't2', t('dash.teachers'), fmtNum(db.teachers.length), `${SUBJECTS.length} ${t('c.subject').toLowerCase()}`, 'teachers')}
    ${tile('fa-school', 't3', t('dash.classes'), fmtNum(db.classes.length), `${gradeLabel(1)}–${gradeLabel(4)}: ${lower} · ${gradeLabel(5)}–${gradeLabel(7)}: ${db.classes.length - lower}`, 'classes')}
    ${tile('fa-clipboard-check', 't4', t('dash.attToday'), tot ? `${Math.round((pres / tot) * 100)}%` : `<span class="stat-na">${t('dash.notTaken')}</span>`, t('dash.classesTaken', { n: taken, t: db.classes.length }), 'attendance')}
  </div>

  ${!db.teachers.length || !S.length ? `
  <div class="card getting-started">
    <div class="card-head"><h3><i class="fa-solid fa-flag-checkered"></i> ${t('gs.title')}</h3></div>
    <ol class="gs-steps">
      ${[['teachers', 'fa-chalkboard-user', db.teachers.length], ['classes', 'fa-user-tie', db.classes.some((c) => Object.keys(c.teachers || {}).length)], ['students', 'fa-user-graduate', S.length], ['accounts', 'fa-user-shield', db.accounts.length > 1]]
        .map(([p, i, done], k) => `<li class="${done ? 'done' : ''}"><a href="#${p}"><span class="gs-num">${done ? '<i class="fa-solid fa-check"></i>' : k + 1}</span><i class="fa-solid ${i}"></i><span>${t('gs.' + (k + 1))}</span></a></li>`).join('')}
    </ol>
  </div>` : ''}

  <div class="grid-2">
    <div class="card">
      <div class="card-head"><h3>${t('dash.byGrade')}</h3><span class="muted">${fmtNum(S.length)} ${t('c.students')}</span></div>
      <div class="barchart" role="img" aria-label="${t('dash.byGrade')}: ${byGrade.map((x) => `${gradeLabel(x.g)} ${x.n}`).join(', ')}">
        <div class="bc-grid">${[1, 0.5, 0].map((f) => `<div><span>${Math.round(niceMax * f)}</span></div>`).join('')}</div>
        <div class="bc-bars">
          ${byGrade.map((x) => `
            <div class="bc-col" tabindex="0" data-tip="${gradeLabel(x.g)}: ${x.n} ${t('c.students')} · ${x.k} ${t('c.class').toLowerCase()}">
              <span class="bc-val">${x.n}</span>
              <div class="bc-bar" style="height:${(x.n / niceMax) * 100}%"></div>
            </div>`).join('')}
        </div>
        <div class="bc-axis">${byGrade.map((x) => `<span>${gradeLabel(x.g)}</span>`).join('')}</div>
      </div>
    </div>

    <div class="card">
      <div class="card-head"><h3>${t('dash.feeProgress')}</h3><a class="link" href="#fees">${t('nav.fees')} <i class="fa-solid fa-arrow-right"></i></a></div>
      <div class="meter-big"><b>${feePct}%</b><span class="muted">${t('dash.collected')} ${fmtKip(col)} / ${fmtKip(exp)}</span></div>
      <div class="meter" role="progressbar" aria-valuenow="${feePct}" aria-valuemin="0" aria-valuemax="100" data-tip="${t('dash.collected')}: ${fmtKip(col)} · ${t('fe.remain')}: ${fmtKip(exp - col)}"><div style="width:${feePct}%"></div></div>
      <ul class="fee-split">
        ${['paid', 'partial', 'unpaid'].map((k) => `<li>${feeBadge(k)}<b>${cnt[k]}</b><span class="muted">${t('c.students')}</span></li>`).join('')}
      </ul>
    </div>

    <div class="card">
      <div class="card-head"><h3>${t('dash.topStudents')}</h3><a class="link" href="#grades">${t('nav.grades')} <i class="fa-solid fa-arrow-right"></i></a></div>
      <ol class="top-list">
        ${top.map((x, i) => `<li><span class="pos p${i + 1}">${i + 1}</span>${personCell(x.s, className(classById(x.s.classId)))}<span class="score-pill">${fmtScore(x.a)}</span>${rankBadge(x.a)}</li>`).join('') || `<li class="muted">${t('c.noData')}</li>`}
      </ol>
    </div>

    <div class="card">
      <div class="card-head"><h3>${t('dash.events')}</h3><button class="btn sm ghost" data-act="addEvent"><i class="fa-solid fa-plus"></i> ${t('dash.addEvent')}</button></div>
      <ul class="events">
        ${events.map((e) => {
          const [y, m, d] = e.date.split('-');
          return `<li><div class="ev-date"><b>${d}</b><small>${m}/${y}</small></div><span class="ev-name">${esc(e.name)}</span><button class="icon-btn sm danger" data-act="delEvent" data-id="${e.id}" aria-label="${t('c.delete')}"><i class="fa-regular fa-trash-can"></i></button></li>`;
        }).join('') || `<li class="muted">${t('c.noData')}</li>`}
      </ul>
    </div>
  </div>`;
};

// ---------- Học sinh ----------
function filteredStudents() {
  const q = norm(ui.st.q);
  return db.students
    .filter((s) => (!ui.st.cls || s.classId === ui.st.cls) && (!ui.st.gender || s.gender === ui.st.gender) &&
      (!q || norm(`${s.name} ${s.code} ${s.parent} ${s.parentPhone}`).includes(q)))
    .sort((a, b) => classOrder(a) - classOrder(b) || byName(a, b));
}

function studentList() {
  const list = filteredStudents();
  const pages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
  ui.st.page = Math.min(Math.max(1, ui.st.page), pages);
  const rows = list.slice((ui.st.page - 1) * PAGE_SIZE, ui.st.page * PAGE_SIZE);
  return `<div class="table-wrap"><table class="table">
    <thead><tr><th>${t('c.code')}</th><th>${t('c.name')}</th><th>${t('st.dob')}</th><th>${t('c.class')}</th><th>${t('st.parent')}</th><th>${t('nav.fees')}</th><th>${t('acc.email')}</th><th class="right">${t('c.actions')}</th></tr></thead>
    <tbody>${rows.map((s) => `<tr>
      <td class="mono">${esc(s.code)}</td>
      <td>${personCell(s, `${genderLabel(s.gender)} · ${esc(loc(ETHNICS[s.ethnic]))}`)}</td>
      <td>${fmtDate(s.dob)}</td>
      <td><span class="chip">${esc(className(classById(s.classId)))}</span></td>
      <td>${esc(s.parent)}<small class="block muted">${esc(s.parentPhone)}</small></td>
      <td>${feeBadge(feeInfo(s).status)}</td>
      <td>${accountCell('student', s.id)}</td>
      <td class="right">${rowActions('Student', s.id)}</td>
    </tr>`).join('') || emptyRow(8)}</tbody>
  </table></div>
  <div class="list-foot"><span class="muted">${t('c.total')}: ${list.length}</span>${pager(list.length, ui.st.page, 'stPage')}</div>`;
}

PAGES.students = () => `
  ${pageHead(t('st.title'), `${db.students.length} ${t('c.students')}`, `
    <button class="btn ghost" data-act="exportStudents"><i class="fa-solid fa-file-csv"></i> ${t('c.exportCsv')}</button>
    <button class="btn primary" data-act="addStudent"><i class="fa-solid fa-plus"></i> ${t('st.add')}</button>`)}
  <div class="card">
    <div class="toolbar">
      <div class="search"><i class="fa-solid fa-magnifying-glass"></i><input type="search" placeholder="${t('c.search')}" value="${esc(ui.st.q)}" data-input="stSearch" aria-label="${t('c.search')}"></div>
      <select data-change="stClass" aria-label="${t('c.class')}">${classOptions(ui.st.cls, true)}</select>
      <select data-change="stGender" aria-label="${t('c.gender')}">${opts([{ v: '', l: `${t('c.gender')}: ${t('c.all')}` }, { v: 'M', l: t('c.male') }, { v: 'F', l: t('c.female') }], ui.st.gender)}</select>
    </div>
    <div id="stList">${studentList()}</div>
  </div>`;

const refreshStudents = () => { const el = $('#stList'); if (el) el.innerHTML = studentList(); };

function studentForm(s) {
  const isNew = !s;
  formModal({
    title: isNew ? t('st.add') : t('st.editTitle'),
    values: s || { code: 'HS' + pad(db.seq.s + 1, 4), gender: 'M', classId: ui.st.cls || (sortedClasses()[0] || {}).id, province: 0, ethnic: 0 },
    fields: [
      { name: 'code', label: t('c.code'), required: true },
      { name: 'name', label: t('c.name'), required: true },
      { name: 'gender', label: t('c.gender'), type: 'select', options: [{ v: 'M', l: t('c.male') }, { v: 'F', l: t('c.female') }] },
      { name: 'dob', label: t('st.dob'), type: 'date' },
      { name: 'classId', label: t('c.class'), type: 'select', required: true, options: sortedClasses().map((c) => ({ v: c.id, l: className(c) })) },
      { name: 'ethnic', label: t('st.ethnic'), type: 'select', options: ETHNICS.map((e, i) => ({ v: i, l: loc(e) })) },
      { name: 'province', label: t('st.province'), type: 'select', options: PROVINCES.map((p, i) => ({ v: i, l: loc(p) })) },
      { name: 'address', label: t('st.address') },
      { name: 'parent', label: t('st.parent') },
      { name: 'parentPhone', label: t('st.parentPhone'), type: 'tel' },
    ],
    onSubmit: (v) => {
      if (db.students.some((x) => x.code.toLowerCase() === v.code.toLowerCase() && x !== s)) return `${t('c.code')} "${v.code}" đã tồn tại / ມີແລ້ວ`;
      v.province = Number(v.province);
      v.ethnic = Number(v.ethnic);
      const id = isNew ? nextId('s') : s.id;
      if (isNew) db.students.push({ id, ...v });
      else Object.assign(s, v);
      save();
      toast(t('c.saved'));
      renderView();
      // Quản lý tạo xong hồ sơ → mở luôn form cấp tài khoản cho học sinh
      if (isNew && can('accounts')) setTimeout(() => accountForm(null, { role: 'student', refId: id }), 0);
    },
  });
}

function studentDetail(s) {
  const c = classById(s.classId);
  const at = attStats(s.id);
  const f = feeInfo(s);
  const info = [
    [t('c.code'), s.code], [t('c.gender'), genderLabel(s.gender)], [t('st.dob'), fmtDate(s.dob)],
    [t('c.class'), className(c)], [t('st.ethnic'), loc(ETHNICS[s.ethnic])], [t('st.province'), loc(PROVINCES[s.province])],
    [t('st.address'), s.address], [t('st.parent'), s.parent], [t('st.parentPhone'), s.parentPhone],
  ];
  openModal({
    title: t('st.detail'),
    wide: true,
    body: `
      <div class="profile">
        <span class="avatar lg ${s.gender}">${esc(initials(s.name))}</span>
        <div><h3>${esc(s.name)}</h3><p class="muted">${esc(s.code)} · ${esc(className(c))} · ${t('cl.homeroom')}: ${esc((teacherById(c && c.homeroomId) || {}).name || '—')}</p></div>
      </div>
      <dl class="info-grid">${info.map(([k, v]) => `<div><dt>${k}</dt><dd>${esc(v || '—')}</dd></div>`).join('')}</dl>
      <div class="detail-cols">
        <div>
          <h4><i class="fa-solid fa-star-half-stroke"></i> ${t('st.gradesSummary')}</h4>
          <div class="table-wrap"><table class="table compact">
            <thead><tr><th>${t('c.subject')}</th><th class="right">${t('c.sem1')}</th><th class="right">${t('c.sem2')}</th></tr></thead>
            <tbody>
              ${SUBJECTS.map((sub) => `<tr><td><span class="dot" style="--c:${sub.color}"></span>${esc(loc(sub))}</td><td class="right">${fmtScore(avgOf(gradeRec(s.id, sub.id, 1))) || '—'}</td><td class="right">${fmtScore(avgOf(gradeRec(s.id, sub.id, 2))) || '—'}</td></tr>`).join('')}
              <tr class="total-row"><td>${t('gr.overall')}</td><td class="right">${fmtScore(overallAvg(s.id, 1)) || '—'} ${rankBadge(overallAvg(s.id, 1))}</td><td class="right">${fmtScore(overallAvg(s.id, 2)) || '—'}</td></tr>
            </tbody>
          </table></div>
        </div>
        <div>
          <h4><i class="fa-solid fa-clipboard-check"></i> ${t('st.attSummary')}</h4>
          <div class="mini-stats">
            <div><b>${pct(at.rate)}</b><span>${t('at.rate')}</span></div>
            <div><b>${at.total}</b><span>${t('at.days')}</span></div>
          </div>
          <ul class="att-counts">${ATT.map((a) => `<li><span class="badge ${a.c}"><i class="fa-solid ${a.i}"></i> ${t(a.l)}</span><b>${at[a.k]}</b></li>`).join('')}</ul>
          <h4><i class="fa-solid fa-money-bill-wave"></i> ${t('st.feeSummary')}</h4>
          <ul class="kv">
            <li><span>${t('fe.required')}</span><b>${fmtKip(f.req)}</b></li>
            <li><span>${t('fe.paid')}</span><b>${fmtKip(f.paid)}</b></li>
            <li><span>${t('fe.remain')}</span><b>${fmtKip(f.remain)}</b></li>
            <li><span>${t('c.status')}</span>${feeBadge(f.status)}</li>
          </ul>
        </div>
      </div>`,
    foot: `<button class="btn ghost" data-close>${t('c.close')}</button>
      ${f.remain > 0 ? `<button class="btn ghost" data-act="collectFee" data-id="${s.id}"><i class="fa-solid fa-hand-holding-dollar"></i> ${t('fe.collect')}</button>` : ''}
      <button class="btn primary" data-act="editStudent" data-id="${s.id}"><i class="fa-regular fa-pen-to-square"></i> ${t('c.edit')}</button>`,
  });
}

function deleteStudent(s) {
  confirmBox(t('c.confirmDelete', { name: s.name }), () => {
    db.students = db.students.filter((x) => x.id !== s.id);
    db.accounts = db.accounts.filter((a) => !(a.role === 'student' && a.refId === s.id));
    db.payments = db.payments.filter((p) => p.studentId !== s.id);
    Object.keys(db.grades).forEach((k) => { if (k.startsWith(s.id + '|')) delete db.grades[k]; });
    Object.values(db.attendance).forEach((r) => { delete r[s.id]; });
    save();
    toast(t('c.deleted'));
    renderView();
  });
}

// ---------- Giáo viên ----------
const teachersOf = (sub) => db.teachers.filter((x) => x.subject === sub).sort(byName);

function teacherRows() {
  const q = norm(ui.tc.q);
  const list = db.teachers
    .filter((x) => (!ui.tc.sub || x.subject === ui.tc.sub) && (!q || norm(`${x.name} ${x.code} ${x.phone} ${x.email}`).includes(q)))
    .sort((a, b) => a.code.localeCompare(b.code));
  return list.map((x) => {
    const sub = subjectById(x.subject);
    const taught = sortedClasses().filter((c) => c.homeroomId === x.id || Object.values(c.teachers || {}).includes(x.id));
    return `<tr>
      <td class="mono">${esc(x.code)}</td>
      <td>${personCell(x, `${genderLabel(x.gender)} · ${esc(loc(DEGREES[x.degree]))}`)}</td>
      <td><span class="dot" style="--c:${sub ? sub.color : '#999'}"></span>${esc(loc(sub))}</td>
      <td><div class="chip-wrap">${taught.map((c) => `<span class="chip${c.homeroomId === x.id ? ' home' : ''}" ${c.homeroomId === x.id ? `title="${t('tc.homeroom')}"` : ''}>${c.homeroomId === x.id ? '<i class="fa-solid fa-star"></i> ' : ''}${esc(className(c))}</span>`).join('') || '<span class="muted">—</span>'}</div></td>
      <td>${esc(x.phone)}<small class="block muted">${esc(x.email)}</small></td>
      <td>${accountCell('teacher', x.id)}</td>
      <td class="right">${rowActions('Teacher', x.id)}</td>
    </tr>`;
  }).join('') || emptyRow(8);
}

PAGES.teachers = () => `
  ${pageHead(t('tc.title'), `${db.teachers.length} ${t('c.people')}`, `
    <button class="btn ghost" data-act="exportTeachers"><i class="fa-solid fa-file-csv"></i> ${t('c.exportCsv')}</button>
    <button class="btn primary" data-act="addTeacher"><i class="fa-solid fa-plus"></i> ${t('tc.add')}</button>`)}
  <div class="card">
    <div class="toolbar">
      <div class="search"><i class="fa-solid fa-magnifying-glass"></i><input type="search" placeholder="${t('c.search')}" value="${esc(ui.tc.q)}" data-input="tcSearch" aria-label="${t('c.search')}"></div>
      <select data-change="tcSub" aria-label="${t('c.subject')}">${opts([{ v: '', l: `${t('c.subject')}: ${t('c.all')}` }, ...SUBJECTS.map((s) => ({ v: s.id, l: loc(s) }))], ui.tc.sub)}</select>
    </div>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>${t('c.code')}</th><th>${t('c.name')}</th><th>${t('c.subject')}</th><th>${t('th.classes')}</th><th>${t('c.phone')} / ${t('c.email')}</th><th>${t('acc.email')}</th><th class="right">${t('c.actions')}</th></tr></thead>
      <tbody id="tcBody">${teacherRows()}</tbody>
    </table></div>
  </div>`;

function teacherForm(x) {
  const isNew = !x;
  formModal({
    title: isNew ? t('tc.add') : t('tc.editTitle'),
    values: x || { code: 'GV' + pad(db.seq.t + 1, 3), gender: 'F', subject: 'math', degree: 1, startYear: new Date().getFullYear() },
    fields: [
      { name: 'code', label: t('c.code'), required: true },
      { name: 'name', label: t('c.name'), required: true },
      { name: 'gender', label: t('c.gender'), type: 'select', options: [{ v: 'M', l: t('c.male') }, { v: 'F', l: t('c.female') }] },
      { name: 'subject', label: t('c.subject'), type: 'select', options: SUBJECTS.map((s) => ({ v: s.id, l: loc(s) })) },
      { name: 'degree', label: t('tc.degree'), type: 'select', options: DEGREES.map((d, i) => ({ v: i, l: loc(d) })) },
      { name: 'startYear', label: t('tc.startYear'), type: 'number', attrs: ' min="1975" max="2100"' },
      { name: 'phone', label: t('c.phone'), type: 'tel' },
      { name: 'email', label: t('c.email'), type: 'email' },
    ],
    onSubmit: (v) => {
      if (db.teachers.some((o) => o.code.toLowerCase() === v.code.toLowerCase() && o !== x)) return `${t('c.code')} "${v.code}" đã tồn tại / ມີແລ້ວ`;
      v.degree = Number(v.degree);
      const id = isNew ? nextId('t') : x.id;
      if (isNew) db.teachers.push({ id, ...v });
      else Object.assign(x, v);
      save();
      toast(t('c.saved'));
      renderView();
      if (isNew && can('accounts')) setTimeout(() => accountForm(null, { role: 'teacher', refId: id }), 0);
    },
  });
}

// ---------- Lớp học ----------
function classCard(c) {
  const list = studentsOf(c.id);
  const male = list.filter((s) => s.gender === 'M').length;
  const hr = teacherById(c.homeroomId);
  return `<div class="class-card">
    <div class="cc-top">
      <span class="cc-name">${esc(className(c))}</span>
      <span class="chip">${t('cl.grade')} ${gradeLabel(c.grade)}</span>
    </div>
    <ul class="cc-info">
      <li><i class="fa-solid fa-chalkboard-user"></i> ${hr ? esc(hr.name) : `<span class="muted">${t('c.none')}</span>`}</li>
      <li><i class="fa-solid fa-door-open"></i> ${t('cl.room')}: ${esc(c.room || '—')}</li>
      <li><i class="fa-solid fa-users"></i> ${t('cl.size')}: <b>${list.length}</b> <span class="muted">(${t('c.male')} ${male} · ${t('c.female')} ${list.length - male})</span></li>
      <li><i class="fa-solid fa-user-tie"></i> ${t('cl.teachers')}: <b>${Object.values(c.teachers || {}).filter(teacherById).length}</b>/${SUBJECTS.length} ${t('c.subject').toLowerCase()}</li>
    </ul>
    <div class="cc-actions">
      <button class="btn sm ghost" data-act="assignTeachers" data-id="${c.id}" title="${t('cl.assign')}"><i class="fa-solid fa-user-tie"></i> ${t('cl.assign')}</button>
      <button class="btn sm ghost" data-act="classStudents" data-id="${c.id}" title="${t('nav.students')}" aria-label="${t('nav.students')}"><i class="fa-solid fa-list"></i></button>
      <button class="btn sm ghost" data-act="classTimetable" data-id="${c.id}"><i class="fa-solid fa-calendar-days"></i></button>
      ${rowActions('Class', c.id)}
    </div>
  </div>`;
}

PAGES.classes = () => {
  const groups = [[t('cl.lower'), (c) => c.grade <= 4], [t('cl.upper'), (c) => c.grade > 4]];
  return `
  ${pageHead(t('cl.title'), `${db.classes.length} ${t('c.class').toLowerCase()} · ${db.students.length} ${t('c.students')}`,
    `<button class="btn primary" data-act="addClass"><i class="fa-solid fa-plus"></i> ${t('cl.add')}</button>`)}
  ${groups.map(([title, fn]) => {
    const list = sortedClasses().filter(fn);
    return `<h3 class="group-title">${title}</h3><div class="class-grid">${list.map(classCard).join('') || `<p class="muted">${t('c.noData')}</p>`}</div>`;
  }).join('')}`;
};

function classForm(c) {
  const isNew = !c;
  formModal({
    title: isNew ? t('cl.add') : t('cl.editTitle'),
    values: c || { grade: 1, homeroomId: '' },
    fields: [
      { name: 'name', label: `${t('cl.name')} (VD: M1/3)`, required: true },
      { name: 'grade', label: t('cl.grade'), type: 'select', options: GRADES.map((g) => ({ v: g, l: gradeLabel(g) })) },
      { name: 'homeroomId', label: t('cl.homeroom'), type: 'select', options: [{ v: '', l: t('c.none') }, ...db.teachers.slice().sort(byName).map((x) => ({ v: x.id, l: `${x.name} (${loc(subjectById(x.subject))})` }))] },
      { name: 'room', label: t('cl.room') },
    ],
    onSubmit: (v) => {
      v.name = v.name.toUpperCase().replace(/^ມ\.?/, 'M');
      if (db.classes.some((o) => o.name === v.name && o !== c)) return `${t('cl.name')} "${v.name}" đã tồn tại / ມີແລ້ວ`;
      v.grade = Number(v.grade);
      if (isNew) {
        const id = nextId('c');
        db.classes.push({ id, ...v, teachers: {} });
        db.timetable[id] = {};
      } else Object.assign(c, v);
      save();
      toast(t('c.saved'));
      renderView();
    },
  });
}

// Phân công giảng dạy: chọn giáo viên cho từng môn của lớp
function assignTeachers(c) {
  const sorted = db.teachers.slice().sort(byName);
  const rows = SUBJECTS.map((sub) => {
    const own = sorted.filter((x) => x.subject === sub.id);
    const other = sorted.filter((x) => x.subject !== sub.id);
    const cur = (c.teachers || {})[sub.id] || '';
    const o = (x) => `<option value="${x.id}"${x.id === cur ? ' selected' : ''}>${esc(x.name)} · ${esc(x.code)}</option>`;
    return `<label class="assign-row"><span><span class="dot" style="--c:${sub.color}"></span>${esc(loc(sub))}</span>
      <select name="${sub.id}"><option value="">${t('cl.notAssigned')}</option>
        ${own.length ? `<optgroup label="${esc(loc(sub))}">${own.map(o).join('')}</optgroup>` : ''}
        <optgroup label="${t('c.all')}">${other.map(o).join('')}</optgroup>
      </select></label>`;
  }).join('');
  const m = openModal({
    title: `${t('cl.assign')} · ${className(c)}`,
    body: `<p class="muted" style="margin-bottom:12px">${t('cl.homeroom')}: <b>${esc((teacherById(c.homeroomId) || {}).name || '—')}</b></p><form class="assign-list">${rows}</form>`,
    foot: `<button class="btn ghost" data-close>${t('c.cancel')}</button><button class="btn primary" data-save><i class="fa-solid fa-check"></i> ${t('c.save')}</button>`,
  });
  $('[data-save]', m).addEventListener('click', () => {
    c.teachers = {};
    $$('select', m).forEach((s) => { if (s.value) c.teachers[s.name] = s.value; });
    save(); closeModal(); toast(t('c.saved')); renderView();
  });
}

// ---------- Điểm số ----------
function gradeStats() {
  const list = studentsOf(ui.gr.cls);
  const count = { exc: 0, good: 0, info: 0, warn: 0, bad: 0 };
  let sum = 0, n = 0;
  list.forEach((s) => {
    const a = avgOf(gradeRec(s.id, ui.gr.sub, ui.gr.sem));
    if (a != null) { sum += a; n++; count[rankOf(a).c]++; }
  });
  const keys = [['exc', 'r.excellent'], ['good', 'r.good'], ['info', 'r.fair'], ['warn', 'r.average'], ['bad', 'r.weak']];
  return `<div class="chips-row"><span class="stat-chip"><b>${n ? (sum / n).toFixed(2) : '—'}</b> ${t('gr.avg')}</span>${keys.map(([c, k]) => `<span class="badge ${c}">${t(k)}: ${count[c]}</span>`).join('')}</div>`;
}

function gradeEntry() {
  const list = studentsOf(ui.gr.cls);
  return `<div id="grStats">${gradeStats()}</div>
  <div class="table-wrap"><table class="table grade-table">
    <thead><tr><th>#</th><th>${t('c.code')}</th><th>${t('c.name')}</th>${PARTS.map((p) => `<th class="center">${t(PART_LABEL[p])}<small class="block muted">×${WEIGHT[p]}</small></th>`).join('')}<th class="center">${t('gr.avg')}</th><th>${t('gr.rank')}</th></tr></thead>
    <tbody>${list.map((s, i) => {
      const g = gradeRec(s.id, ui.gr.sub, ui.gr.sem) || {};
      const a = avgOf(g);
      return `<tr data-sid="${s.id}">
        <td class="muted">${i + 1}</td><td class="mono">${esc(s.code)}</td><td><b>${esc(s.name)}</b></td>
        ${PARTS.map((p) => `<td class="center"><input class="score" type="number" inputmode="decimal" min="0" max="10" step="0.5" value="${g[p] ?? ''}" data-change="score" data-part="${p}" aria-label="${esc(s.name)} ${t(PART_LABEL[p])}"></td>`).join('')}
        <td class="center avg"><b>${fmtScore(a)}</b></td><td class="rank">${rankBadge(a)}</td>
      </tr>`;
    }).join('') || emptyRow(9)}</tbody>
  </table></div>
  <p class="note"><i class="fa-solid fa-circle-info"></i> ${t('gr.formula')}</p>`;
}

function summaryData() {
  const rows = studentsOf(ui.gr.cls).map((s) => ({ s, subs: SUBJECTS.map((sub) => avgOf(gradeRec(s.id, sub.id, ui.gr.sem))), all: overallAvg(s.id, ui.gr.sem) }));
  const sorted = rows.filter((r) => r.all != null).map((r) => r.all).sort((a, b) => b - a);
  rows.forEach((r) => { r.pos = r.all == null ? null : sorted.indexOf(r.all) + 1; });
  return rows;
}

function gradeSummary() {
  const rows = summaryData();
  return `<div class="table-wrap"><table class="table summary-table">
    <thead><tr><th>#</th><th>${t('c.name')}</th>${SUBJECTS.map((s) => `<th class="center sub-h" title="${esc(loc(s))}"><span class="dot" style="--c:${s.color}"></span>${esc(loc(s))}</th>`).join('')}<th class="center">${t('gr.overall')}</th><th>${t('gr.rank')}</th><th class="center">${t('gr.position')}</th></tr></thead>
    <tbody>${rows.map((r, i) => `<tr>
      <td class="muted">${i + 1}</td><td><b>${esc(r.s.name)}</b><small class="block muted">${esc(r.s.code)}</small></td>
      ${r.subs.map((v) => `<td class="center ${v != null && v < 5 ? 'low' : ''}">${fmtScore(v) || '<span class="muted">—</span>'}</td>`).join('')}
      <td class="center"><b>${fmtScore(r.all) || '—'}</b></td><td>${rankBadge(r.all)}</td><td class="center">${r.pos ? `<span class="pos p${Math.min(r.pos, 4)}">${r.pos}</span>` : '—'}</td>
    </tr>`).join('') || emptyRow(SUBJECTS.length + 5)}</tbody>
  </table></div>`;
}

const noClassCard = () => `<div class="card empty-state"><i class="fa-solid fa-people-roof"></i><p>${t('th.noClass')}</p></div>`;

PAGES.grades = () => {
  const classes = myClasses();
  if (!classes.length) return pageHead(t('gr.title'), '') + noClassCard();
  ensureClass(ui.gr, classes);
  const subs = mySubjects(ui.gr.cls);
  if (!subs.some((s) => s.id === ui.gr.sub)) ui.gr.sub = (subs[0] || {}).id || '';
  const entry = ui.gr.mode === 'entry';
  const body = !entry ? gradeSummary() : subs.length ? gradeEntry() : `<p class="alert warn"><i class="fa-solid fa-circle-info"></i> ${t('th.onlyAssigned')}</p>`;
  return `
  ${pageHead(t('gr.title'), `${esc(db.settings.year)}`, entry ? '' : `<button class="btn ghost" data-act="exportSummary"><i class="fa-solid fa-file-csv"></i> ${t('c.exportCsv')}</button>`)}
  <div class="card">
    <div class="toolbar">
      <div class="seg" role="group">
        <button data-act="grMode" data-v="entry" class="${entry ? 'on' : ''}"><i class="fa-solid fa-pen"></i> ${t('gr.entry')}</button>
        <button data-act="grMode" data-v="summary" class="${entry ? '' : 'on'}"><i class="fa-solid fa-table"></i> ${t('gr.summary')}</button>
      </div>
      <select data-change="grClass" aria-label="${t('c.class')}">${classOptions(ui.gr.cls, false, classes)}</select>
      ${entry && subs.length ? `<select data-change="grSub" aria-label="${t('c.subject')}">${opts(subs.map((s) => ({ v: s.id, l: loc(s) })), ui.gr.sub)}</select>` : ''}
      <select data-change="grSem" aria-label="${t('c.semester')}">${opts([{ v: '1', l: t('c.sem1') }, { v: '2', l: t('c.sem2') }], ui.gr.sem)}</select>
    </div>
    ${body}
  </div>`;
};

// ---------- Điểm danh ----------
function attBody() {
  const cid = ui.at.cls;
  const rec = db.attendance[`${cid}|${ui.at.date}`] || {};
  const list = studentsOf(cid);
  const c = { P: 0, L: 0, E: 0, A: 0 };
  list.forEach((s) => { if (rec[s.id]) c[rec[s.id]]++; });
  const unmarked = list.length - c.P - c.L - c.E - c.A;
  const wd = new Date(ui.at.date + 'T00:00:00').getDay();
  return `
  ${wd === 0 || wd === 6 ? `<p class="alert warn"><i class="fa-solid fa-triangle-exclamation"></i> ${t('at.weekend')}</p>` : ''}
  <div class="chips-row">
    ${ATT.map((a) => `<span class="badge ${a.c}"><i class="fa-solid ${a.i}"></i> ${t(a.l)}: ${c[a.k]}</span>`).join('')}
    <span class="badge neutral"><i class="fa-regular fa-circle"></i> ${t('dash.notTaken')}: ${unmarked}</span>
  </div>
  <div class="table-wrap"><table class="table">
    <thead><tr><th>#</th><th>${t('c.code')}</th><th>${t('c.name')}</th><th>${t('c.status')}</th><th class="right">${t('at.rate')}</th></tr></thead>
    <tbody>${list.map((s, i) => {
      const st = attStats(s.id);
      return `<tr>
        <td class="muted">${i + 1}</td><td class="mono">${esc(s.code)}</td><td>${personCell(s, genderLabel(s.gender))}</td>
        <td><div class="att-seg" role="group" aria-label="${esc(s.name)}">${ATT.map((a) => `<button class="${a.c} ${rec[s.id] === a.k ? 'on' : ''}" aria-pressed="${rec[s.id] === a.k}" data-act="mark" data-sid="${s.id}" data-v="${a.k}"><i class="fa-solid ${a.i}"></i><span>${t(a.l)}</span></button>`).join('')}</div></td>
        <td class="right"><b>${pct(st.rate)}</b><small class="block muted">${st.total} ${t('at.days').toLowerCase()}</small></td>
      </tr>`;
    }).join('') || emptyRow(5)}</tbody>
  </table></div>`;
}

PAGES.attendance = () => {
  const classes = myClasses();
  if (!classes.length) return pageHead(t('at.title'), '') + noClassCard();
  ensureClass(ui.at, classes);
  return `
  ${pageHead(t('at.title'), fmtDate(ui.at.date))}
  <div class="card">
    <div class="toolbar">
      <select data-change="atClass" aria-label="${t('c.class')}">${classOptions(ui.at.cls, false, classes)}</select>
      <input type="date" value="${ui.at.date}" max="${todayIso()}" data-change="atDate" aria-label="${t('c.date')}">
      <button class="btn ghost" data-act="allPresent"><i class="fa-solid fa-check-double"></i> ${t('at.allPresent')}</button>
    </div>
    <div id="atBody">${attBody()}</div>
  </div>`;
};

// ---------- Học phí ----------
function filteredFees() {
  const q = norm(ui.fe.q);
  return db.students
    .filter((s) => (!ui.fe.cls || s.classId === ui.fe.cls) && (!q || norm(`${s.name} ${s.code}`).includes(q)))
    .map((s) => ({ s, f: feeInfo(s) }))
    .filter((x) => !ui.fe.status || x.f.status === ui.fe.status)
    .sort((a, b) => classOrder(a.s) - classOrder(b.s) || byName(a.s, b.s));
}

function feeList() {
  const list = filteredFees();
  const pages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
  ui.fe.page = Math.min(Math.max(1, ui.fe.page), pages);
  const rows = list.slice((ui.fe.page - 1) * PAGE_SIZE, ui.fe.page * PAGE_SIZE);
  return `<div class="table-wrap"><table class="table">
    <thead><tr><th>${t('c.code')}</th><th>${t('c.name')}</th><th>${t('c.class')}</th><th class="right">${t('fe.required')}</th><th class="right">${t('fe.paid')}</th><th class="right">${t('fe.remain')}</th><th>${t('c.status')}</th><th class="right">${t('c.actions')}</th></tr></thead>
    <tbody>${rows.map(({ s, f }) => `<tr>
      <td class="mono">${esc(s.code)}</td>
      <td><b>${esc(s.name)}</b><div class="mini-meter" data-tip="${f.req ? Math.round((f.paid / f.req) * 100) : 0}%"><div style="width:${f.req ? Math.min(100, (f.paid / f.req) * 100) : 0}%"></div></div></td>
      <td><span class="chip">${esc(className(classById(s.classId)))}</span></td>
      <td class="right num">${fmtKip(f.req)}</td>
      <td class="right num">${fmtKip(f.paid)}</td>
      <td class="right num ${f.remain ? 'debt' : ''}">${fmtKip(f.remain)}</td>
      <td>${feeBadge(f.status)}</td>
      <td class="right"><div class="row-actions">
        <button class="btn sm primary" data-act="collectFee" data-id="${s.id}" ${f.remain ? '' : 'disabled'}><i class="fa-solid fa-hand-holding-dollar"></i> ${t('fe.collect')}</button>
        <button class="icon-btn sm" data-act="feeHistory" data-id="${s.id}" title="${t('fe.history')}" aria-label="${t('fe.history')}"><i class="fa-solid fa-clock-rotate-left"></i></button>
      </div></td>
    </tr>`).join('') || emptyRow(8)}</tbody>
  </table></div>
  <div class="list-foot"><span class="muted">${t('c.total')}: ${list.length}</span>${pager(list.length, ui.fe.page, 'fePage')}</div>`;
}

PAGES.fees = () => {
  let exp = 0, col = 0;
  db.students.forEach((s) => { const f = feeInfo(s); exp += f.req; col += Math.min(f.paid, f.req); });
  return `
  ${pageHead(t('fe.title'), `${t('se.year')} ${esc(db.settings.year)} · ${t('se.feeLower')}: ${fmtKip(db.settings.feeLower)} · ${t('se.feeUpper')}: ${fmtKip(db.settings.feeUpper)}`,
    `<button class="btn ghost" data-act="exportFees"><i class="fa-solid fa-file-csv"></i> ${t('c.exportCsv')}</button>`)}
  <div class="stats three">
    <div class="stat t1"><div class="stat-icon"><i class="fa-solid fa-file-invoice-dollar"></i></div><div><span class="stat-label">${t('dash.expected')}</span><b class="stat-value">${fmtKip(exp)}</b></div></div>
    <div class="stat t3"><div class="stat-icon"><i class="fa-solid fa-sack-dollar"></i></div><div><span class="stat-label">${t('fe.collectedTotal')}</span><b class="stat-value">${fmtKip(col)}</b><small>${exp ? Math.round((col / exp) * 100) : 0}%</small></div></div>
    <div class="stat t4"><div class="stat-icon"><i class="fa-solid fa-scale-unbalanced"></i></div><div><span class="stat-label">${t('fe.debtTotal')}</span><b class="stat-value">${fmtKip(exp - col)}</b></div></div>
  </div>
  <div class="card">
    <div class="toolbar">
      <div class="search"><i class="fa-solid fa-magnifying-glass"></i><input type="search" placeholder="${t('c.search')}" value="${esc(ui.fe.q)}" data-input="feSearch" aria-label="${t('c.search')}"></div>
      <select data-change="feClass" aria-label="${t('c.class')}">${classOptions(ui.fe.cls, true)}</select>
      <select data-change="feStatus" aria-label="${t('c.status')}">${opts([{ v: '', l: `${t('c.status')}: ${t('c.all')}` }, { v: 'paid', l: t('fe.st.paid') }, { v: 'partial', l: t('fe.st.partial') }, { v: 'unpaid', l: t('fe.st.unpaid') }], ui.fe.status)}</select>
    </div>
    <div id="feList">${feeList()}</div>
  </div>`;
};

const methodLabel = (m) => t(m === 'transfer' ? 'fe.transfer' : 'fe.cash');

function receiptHtml(p) {
  const s = studentById(p.studentId) || { name: '?', code: '', parent: '' };
  const f = s.id ? feeInfo(s) : { req: 0, paid: 0, remain: 0 };
  return `<div class="receipt">
    <div class="rc-head">
      <div><b>${esc(db.settings.nameLo)}</b><br><b>${esc(db.settings.nameVi)}</b><br><small>${esc(db.settings.address)} · ${esc(db.settings.phone)}</small></div>
      <div class="rc-no">${t('fe.receipt')}<br><b>${esc(p.no)}</b></div>
    </div>
    <h2>${t('fe.receiptTitle')}</h2>
    <p class="center">${t('se.year')} ${esc(db.settings.year)}</p>
    <table>
      <tr><td>${t('c.name')}</td><td><b>${esc(s.name)}</b> (${esc(s.code)})</td></tr>
      <tr><td>${t('c.class')}</td><td>${esc(className(classById(s.classId)))}</td></tr>
      <tr><td>${t('fe.payer')}</td><td>${esc(s.parent || '')}</td></tr>
      <tr><td>${t('c.date')}</td><td>${fmtDate(p.date)}</td></tr>
      <tr><td>${t('fe.method')}</td><td>${methodLabel(p.method)}</td></tr>
      <tr><td>${t('fe.amount')}</td><td><b class="big">${fmtKip(p.amount)}</b></td></tr>
      <tr><td>${t('fe.remain')}</td><td>${fmtKip(f.remain)}</td></tr>
      ${p.note ? `<tr><td>${t('c.note')}</td><td>${esc(p.note)}</td></tr>` : ''}
    </table>
    <div class="rc-sign"><div>${t('fe.payer')}<br><br><br>……………………</div><div>${t('fe.receiver')}<br><br><br>……………………</div></div>
  </div>`;
}

function showReceipt(p) {
  openModal({
    title: `${t('fe.receipt')} ${p.no}`,
    body: receiptHtml(p),
    foot: `<button class="btn ghost" data-close>${t('c.close')}</button><button class="btn primary" data-act="printReceipt" data-id="${p.id}"><i class="fa-solid fa-print"></i> ${t('fe.print')}</button>`,
  });
}

function collectFee(s) {
  const f = feeInfo(s);
  formModal({
    title: `${t('fe.collect')} · ${s.name}`,
    submitLabel: t('fe.collect'),
    intro: `<ul class="kv boxed"><li><span>${t('c.class')}</span><b>${esc(className(classById(s.classId)))}</b></li><li><span>${t('fe.required')}</span><b>${fmtKip(f.req)}</b></li><li><span>${t('fe.paid')}</span><b>${fmtKip(f.paid)}</b></li><li><span>${t('fe.remain')}</span><b class="debt">${fmtKip(f.remain)}</b></li></ul>`,
    values: { amount: f.remain, date: todayIso(), method: 'cash' },
    fields: [
      { name: 'amount', label: t('fe.amount'), type: 'number', required: true, attrs: ` min="1000" step="1000" max="${f.remain}"` },
      { name: 'date', label: t('c.date'), type: 'date', required: true },
      { name: 'method', label: t('fe.method'), type: 'select', options: [{ v: 'cash', l: t('fe.cash') }, { v: 'transfer', l: t('fe.transfer') }] },
      { name: 'note', label: t('c.note') },
    ],
    onSubmit: (v) => {
      if (!(v.amount > 0)) return t('fe.invalidAmount');
      if (v.amount > f.remain) return `${t('fe.overpay')} (${fmtKip(f.remain)})`;
      const id = nextId('p');
      const p = { id, no: 'BL' + pad(db.seq.p, 5), studentId: s.id, amount: Math.round(v.amount), date: v.date, method: v.method, note: v.note };
      db.payments.push(p);
      save();
      toast(t('c.saved'));
      renderView();
      setTimeout(() => showReceipt(p), 0);
    },
  });
}

function feeHistory(s) {
  const list = db.payments.filter((p) => p.studentId === s.id).sort((a, b) => b.date.localeCompare(a.date));
  const f = feeInfo(s);
  openModal({
    title: `${t('fe.history')} · ${s.name}`,
    wide: true,
    body: `<ul class="kv boxed"><li><span>${t('fe.required')}</span><b>${fmtKip(f.req)}</b></li><li><span>${t('fe.paid')}</span><b>${fmtKip(f.paid)}</b></li><li><span>${t('fe.remain')}</span><b class="${f.remain ? 'debt' : ''}">${fmtKip(f.remain)}</b></li><li><span>${t('c.status')}</span>${feeBadge(f.status)}</li></ul>
    <div class="table-wrap"><table class="table compact">
      <thead><tr><th>${t('fe.receipt')}</th><th>${t('c.date')}</th><th>${t('fe.method')}</th><th class="right">${t('fe.amount')}</th><th>${t('c.note')}</th><th class="right">${t('c.actions')}</th></tr></thead>
      <tbody>${list.map((p) => `<tr><td class="mono">${esc(p.no)}</td><td>${fmtDate(p.date)}</td><td>${methodLabel(p.method)}</td><td class="right num"><b>${fmtKip(p.amount)}</b></td><td>${esc(p.note)}</td>
        <td class="right"><div class="row-actions"><button class="icon-btn sm" data-act="openReceipt" data-id="${p.id}" aria-label="${t('fe.print')}" title="${t('fe.print')}"><i class="fa-solid fa-print"></i></button><button class="icon-btn sm danger" data-act="delPayment" data-id="${p.id}" aria-label="${t('c.delete')}" title="${t('c.delete')}"><i class="fa-regular fa-trash-can"></i></button></div></td></tr>`).join('') || emptyRow(6)}</tbody>
    </table></div>`,
    foot: `<button class="btn ghost" data-close>${t('c.close')}</button>${f.remain ? `<button class="btn primary" data-act="collectFee" data-id="${s.id}"><i class="fa-solid fa-hand-holding-dollar"></i> ${t('fe.collect')}</button>` : ''}`,
  });
}

// ---------- Thời khóa biểu ----------
function timetableTable(cid, edit) {
  const grid = db.timetable[cid] || {};
  const cell = (d, p) => {
    const sub = subjectById(grid[`${d}-${p}`]);
    if (edit) return `<td><select class="tt-select" data-change="ttCell" data-slot="${d}-${p}" aria-label="${t('d.' + d)} ${t('tt.period')} ${p}">${opts([{ v: '', l: '—' }, ...SUBJECTS.map((s) => ({ v: s.id, l: loc(s) }))], sub ? sub.id : '')}</select></td>`;
    if (!sub) return '<td><span class="muted">—</span></td>';
    const tc = teacherFor(sub.id, cid);
    return `<td><div class="tt-cell" style="--c:${sub.color}"><b>${esc(loc(sub))}</b><small>${esc(tc ? tc.name : '')}</small></div></td>`;
  };
  return `<table class="table tt">
    <thead><tr><th>${t('tt.period')}</th>${DAYS.map((d) => `<th>${t('d.' + d)}</th>`).join('')}</tr></thead>
    <tbody>${PERIODS.map((p) => `${p === 5 ? `<tr class="tt-break"><td colspan="${DAYS.length + 1}"><i class="fa-solid fa-bowl-rice"></i> 11:30 – 13:30</td></tr>` : ''}
      <tr><th class="tt-p">${p}<small>${PERIOD_TIME[p - 1]}</small></th>${DAYS.map((d) => cell(d, p)).join('')}</tr>`).join('')}</tbody>
  </table>`;
}

PAGES.timetable = () => {
  const cid = ensureClass(ui.tt);
  const grid = db.timetable[cid] || {};
  const load = {};
  Object.values(grid).forEach((s) => { if (s) load[s] = (load[s] || 0) + 1; });
  const c = classById(cid);
  return `
  ${pageHead(t('tt.title'), `${esc(className(c))} · ${t('cl.homeroom')}: ${esc((teacherById(c && c.homeroomId) || {}).name || '—')}`, `
    <button class="btn ghost" data-act="printTimetable"><i class="fa-solid fa-print"></i></button>
    <button class="btn ${ui.tt.edit ? 'primary' : 'ghost'}" data-act="ttEdit"><i class="fa-solid ${ui.tt.edit ? 'fa-check' : 'fa-pen'}"></i> ${t(ui.tt.edit ? 'tt.done' : 'tt.edit')}</button>`)}
  <div class="card">
    <div class="toolbar">
      <select data-change="ttClass" aria-label="${t('c.class')}">${classOptions(cid)}</select>
      <span class="muted"><i class="fa-regular fa-clock"></i> ${t('tt.hint')}</span>
    </div>
    <div class="table-wrap">${timetableTable(cid, ui.tt.edit)}</div>
    <div class="chips-row load">${SUBJECTS.filter((s) => load[s.id]).map((s) => `<span class="load-chip"><span class="dot" style="--c:${s.color}"></span>${esc(loc(s))}: <b>${load[s.id]}</b></span>`).join('')}</div>
  </div>`;
};

// ---------- Cài đặt ----------
PAGES.settings = () => {
  const s = db.settings;
  const inp = (name, label, val, type = 'text', extra = '') => `<label class="field"><span>${label}</span><input name="${name}" type="${type}" value="${esc(val)}"${extra}></label>`;
  return `
  ${pageHead(t('se.title'), '')}
  <div class="settings-grid">
    <form class="card" id="fSchool">
      <div class="card-head"><h3><i class="fa-solid fa-school"></i> ${t('se.school')}</h3></div>
      <div class="form-grid">
        ${inp('nameVi', t('se.nameVi'), s.nameVi)}
        ${inp('nameLo', t('se.nameLo'), s.nameLo)}
        ${inp('address', t('se.address'), s.address)}
        ${inp('principal', t('se.principal'), s.principal)}
        ${inp('phone', t('c.phone'), s.phone, 'tel')}
        ${inp('year', t('se.year'), s.year)}
      </div>
      <div class="card-foot"><button class="btn primary" data-act="saveSchool"><i class="fa-solid fa-check"></i> ${t('c.save')}</button></div>
    </form>

    <div class="stack">
      <form class="card" id="fFee">
        <div class="card-head"><h3><i class="fa-solid fa-money-bill-wave"></i> ${t('se.fees')}</h3></div>
        <div class="form-grid">
          ${inp('feeLower', t('se.feeLower'), s.feeLower, 'number', ' min="0" step="50000"')}
          ${inp('feeUpper', t('se.feeUpper'), s.feeUpper, 'number', ' min="0" step="50000"')}
        </div>
        <div class="card-foot"><button class="btn primary" data-act="saveFees"><i class="fa-solid fa-check"></i> ${t('c.save')}</button></div>
      </form>

      <div class="card">
        <div class="card-head"><h3><i class="fa-solid fa-palette"></i> ${t('se.display')}</h3></div>
        <div class="setting-row"><span>${t('se.lang')}</span>${langSwitch()}</div>
        <div class="setting-row"><span>${t('se.theme')}</span>
          <div class="seg"><button data-act="setTheme" data-v="light" class="${!isDark() ? 'on' : ''}"><i class="fa-solid fa-sun"></i> ${t('se.light')}</button><button data-act="setTheme" data-v="dark" class="${isDark() ? 'on' : ''}"><i class="fa-solid fa-moon"></i> ${t('se.dark')}</button></div>
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-head"><h3><i class="fa-solid fa-database"></i> ${t('se.data')}</h3></div>
      <p class="muted">${t('se.storage')}</p>
      <div class="btn-col">
        <button class="btn ghost" data-act="backup"><i class="fa-solid fa-download"></i> ${t('se.backup')}</button>
        <label class="btn ghost file-btn"><i class="fa-solid fa-upload"></i> ${t('se.restore')}<input type="file" accept="application/json,.json" data-change="restore" hidden></label>
        <button class="btn danger-ghost" data-act="resetData"><i class="fa-solid fa-rotate-left"></i> ${t('se.reset')}</button>
      </div>
    </div>
  </div>`;
};

// ===== Xử lý sự kiện =====
// ---------- Tài khoản & phân quyền (quản lý) ----------
const ROLE_BADGE = { admin: 'exc', teacher: 'info', student: 'neutral' };
const roleBadge = (r) => `<span class="badge ${ROLE_BADGE[r]}"><i class="fa-solid ${r === 'admin' ? 'fa-user-shield' : r === 'teacher' ? 'fa-chalkboard-user' : 'fa-user-graduate'}"></i> ${t('role.' + r)}</span>`;
const suggestEmail = (role, refId) => {
  const p = role === 'teacher' ? teacherById(refId) : role === 'student' ? studentById(refId) : null;
  return p ? `${p.code.toLowerCase()}@${EMAIL_DOMAIN}` : '';
};

function filteredAccounts() {
  const q = norm(ui.acc.q);
  const order = { admin: 0, teacher: 1, student: 2 };
  return db.accounts
    .filter((a) => (!ui.acc.role || a.role === ui.acc.role) && (!q || norm(`${a.email} ${displayName(a)}`).includes(q)))
    .sort((a, b) => order[a.role] - order[b.role] || a.email.localeCompare(b.email));
}

function accountList() {
  const list = filteredAccounts();
  const pages = Math.max(1, Math.ceil(list.length / PAGE_SIZE));
  ui.acc.page = Math.min(Math.max(1, ui.acc.page), pages);
  const rows = list.slice((ui.acc.page - 1) * PAGE_SIZE, ui.acc.page * PAGE_SIZE);
  const self = me().id;
  return `<div class="table-wrap"><table class="table">
    <thead><tr><th>${t('acc.email')}</th><th>${t('acc.role')}</th><th>${t('acc.person')}</th><th>${t('acc.perms')}</th><th>${t('c.status')}</th><th>${t('acc.lastLogin')}</th><th class="right">${t('c.actions')}</th></tr></thead>
    <tbody>${rows.map((a) => {
      const p = a.role === 'teacher' ? teacherById(a.refId) : a.role === 'student' ? studentById(a.refId) : null;
      const sub = p ? (a.role === 'student' ? `${esc(p.code)} · ${esc(className(classById(p.classId)))}` : `${esc(p.code)} · ${esc(loc(subjectById(p.subject)))}`) : '';
      const all = ROLE_PERMS[a.role];
      return `<tr>
        <td><b class="email">${esc(a.email)}</b>${a.id === self ? ` <span class="chip">★</span>` : ''}</td>
        <td>${roleBadge(a.role)}</td>
        <td>${esc(displayName(a))}<small class="block muted">${sub}</small></td>
        <td><span class="perm-count" tabindex="0" data-tip="${esc(all.filter((k) => a.perms.includes(k)).map((k) => t('nav.' + k)).join(', ') || '—')}">${t('acc.permCount', { n: all.filter((k) => a.perms.includes(k)).length, t: all.length })}</span></td>
        <td>${a.active ? `<span class="badge good"><i class="fa-solid fa-circle-check"></i> ${t('acc.active')}</span>` : `<span class="badge bad"><i class="fa-solid fa-lock"></i> ${t('acc.locked')}</span>`}</td>
        <td>${a.lastLogin ? fmtDateTime(a.lastLogin) : `<span class="muted">${t('acc.never')}</span>`}</td>
        <td class="right"><div class="row-actions">
          <button class="icon-btn sm" data-act="editAccount" data-id="${a.id}" title="${t('c.edit')}" aria-label="${t('c.edit')}"><i class="fa-regular fa-pen-to-square"></i></button>
          <button class="icon-btn sm" data-act="resetPass" data-id="${a.id}" title="${t('acc.resetPass')}" aria-label="${t('acc.resetPass')}"><i class="fa-solid fa-key"></i></button>
          <button class="icon-btn sm" data-act="toggleLock" data-id="${a.id}" title="${t(a.active ? 'acc.lock' : 'acc.unlock')}" aria-label="${t(a.active ? 'acc.lock' : 'acc.unlock')}" ${a.id === self ? 'disabled' : ''}><i class="fa-solid ${a.active ? 'fa-lock' : 'fa-lock-open'}"></i></button>
          <button class="icon-btn sm danger" data-act="delAccount" data-id="${a.id}" title="${t('c.delete')}" aria-label="${t('c.delete')}" ${a.id === self ? 'disabled' : ''}><i class="fa-regular fa-trash-can"></i></button>
        </div></td>
      </tr>`;
    }).join('') || emptyRow(7)}</tbody>
  </table></div>
  <div class="list-foot"><span class="muted">${t('c.total')}: ${list.length}</span>${pager(list.length, ui.acc.page, 'accPage')}</div>`;
}

PAGES.accounts = () => {
  const noT = db.teachers.filter((x) => !accountOf('teacher', x.id)).length;
  const noS = db.students.filter((s) => !accountOf('student', s.id)).length;
  const count = (r) => db.accounts.filter((a) => a.role === r).length;
  return `
  ${pageHead(t('acc.title'), t('acc.sub'), `
    <button class="btn ghost" data-act="bulkAccounts"><i class="fa-solid fa-users-gear"></i> ${t('acc.bulk')}</button>
    <button class="btn primary" data-act="newAccount"><i class="fa-solid fa-user-plus"></i> ${t('acc.add')}</button>`)}
  <div class="stats">
    ${['admin', 'teacher', 'student'].map((r, i) => `<div class="stat t${[2, 1, 3][i]}"><div class="stat-icon"><i class="fa-solid ${r === 'admin' ? 'fa-user-shield' : r === 'teacher' ? 'fa-chalkboard-user' : 'fa-user-graduate'}"></i></div><div><span class="stat-label">${t('role.' + r)}</span><b class="stat-value">${count(r)}</b>${r === 'teacher' ? `<small>${t('acc.without', { role: t('role.teacher'), n: noT })}</small>` : r === 'student' ? `<small>${t('acc.without', { role: t('role.student'), n: noS })}</small>` : ''}</div></div>`).join('')}
    <div class="stat t4"><div class="stat-icon"><i class="fa-solid fa-lock"></i></div><div><span class="stat-label">${t('acc.locked')}</span><b class="stat-value">${db.accounts.filter((a) => !a.active).length}</b></div></div>
  </div>
  <div class="card">
    <div class="toolbar">
      <div class="search"><i class="fa-solid fa-magnifying-glass"></i><input type="search" placeholder="${t('c.search')}" value="${esc(ui.acc.q)}" data-input="accSearch" aria-label="${t('c.search')}"></div>
      <select data-change="accRole" aria-label="${t('acc.role')}">${opts([{ v: '', l: `${t('acc.role')}: ${t('c.all')}` }, ...['admin', 'teacher', 'student'].map((r) => ({ v: r, l: t('role.' + r) }))], ui.acc.role)}</select>
    </div>
    <div id="accList">${accountList()}</div>
  </div>
  <p class="note"><i class="fa-solid fa-shield-halved"></i> ${t('acc.demoNote')}</p>`;
};

// Form tạo / sửa tài khoản: chọn vai trò → người dùng → email, mật khẩu → tích chọn chức năng được dùng
function accountForm(a, preset = {}) {
  const isNew = !a;
  const self = !!a && a.id === me().id;
  let role = a ? a.role : preset.role || 'teacher';
  let autoEmail = isNew;

  const personField = (r, sel) => {
    if (r === 'admin') return `<label class="field"><span>${t('acc.displayName')} <span class="req">*</span></span><input name="name" value="${esc(a ? a.name : '')}"></label>`;
    const list = r === 'teacher' ? db.teachers.slice().sort(byName) : db.students.slice().sort((x, y) => classOrder(x) - classOrder(y) || byName(x, y));
    return `<label class="field"><span>${t('acc.person')} <span class="req">*</span></span><select name="refId"><option value="">—</option>${list.map((p) => {
      const taken = accountOf(r, p.id);
      const dis = taken && (!a || taken.id !== a.id);
      const extra = r === 'student' ? ` · ${className(classById(p.classId))}` : ` · ${loc(subjectById(p.subject))}`;
      return `<option value="${p.id}"${p.id === sel ? ' selected' : ''}${dis ? ' disabled' : ''}>${esc(p.code)} · ${esc(p.name)}${esc(extra)}${dis ? ` (${t('acc.hasAccount')})` : ''}</option>`;
    }).join('')}</select></label>`;
  };
  const permsHtml = (r, checked) => ROLE_PERMS[r].map((k) => `<label class="perm">
      <input type="checkbox" value="${k}"${checked.includes(k) ? ' checked' : ''}${self && k === 'accounts' ? ' disabled' : ''}>
      <i class="fa-solid ${PERM_ICON[k] || 'fa-circle'}"></i>
      <span><b>${t('nav.' + k)}</b><small>${t('perm.' + k)}</small></span>
    </label>`).join('');

  const m = openModal({
    title: isNew ? t('acc.add') : t('acc.editTitle'),
    wide: true,
    body: `<form class="form-grid" id="accForm" novalidate>
      <label class="field"><span>${t('acc.role')}</span><select name="role"${isNew ? '' : ' disabled'}>${opts(['admin', 'teacher', 'student'].map((r) => ({ v: r, l: t('role.' + r) })), role)}</select></label>
      <div id="accPerson">${personField(role, a ? a.refId : preset.refId || '')}</div>
      <label class="field"><span>${t('acc.email')} <span class="req">*</span></span><input name="email" type="email" autocomplete="off" value="${esc(a ? a.email : suggestEmail(role, preset.refId))}" placeholder="name@icloud.com"></label>
      <label class="field"><span>${isNew ? `${t('acc.pass')} <span class="req">*</span>` : t('acc.passKeep')}</span><input name="pass" type="text" autocomplete="new-password" value="${isNew ? '123456' : ''}"></label>
      <div class="full">
        <div class="perm-head"><span>${t('acc.perms')}</span><button type="button" class="link" data-perm-all><i class="fa-solid fa-check-double"></i> ${t('acc.selectAll')}</button></div>
        <div class="perm-grid" id="accPerms">${permsHtml(role, a ? a.perms : ROLE_PERMS[role])}</div>
      </div>
      <label class="check full"><input type="checkbox" name="active"${!a || a.active ? ' checked' : ''}${self ? ' disabled' : ''}> ${t('acc.active')}</label>
      <p class="form-error full" hidden></p>
    </form>`,
    foot: `<button class="btn ghost" data-close>${t('c.cancel')}</button><button class="btn primary" data-save><i class="fa-solid fa-check"></i> ${t('c.save')}</button>`,
  });
  const f = $('#accForm', m);
  const err = $('.form-error', f);
  f.elements.role.addEventListener('change', () => {
    role = f.elements.role.value;
    $('#accPerson', m).innerHTML = personField(role, '');
    $('#accPerms', m).innerHTML = permsHtml(role, ROLE_PERMS[role]);
    if (autoEmail) f.elements.email.value = '';
  });
  f.addEventListener('change', (e) => {
    if (e.target.name === 'refId' && autoEmail) f.elements.email.value = suggestEmail(role, e.target.value);
  });
  f.elements.email.addEventListener('input', () => { autoEmail = false; });
  $('[data-perm-all]', m).addEventListener('click', () => {
    const boxes = $$('#accPerms input:not(:disabled)', m);
    const on = !boxes.every((b) => b.checked);
    boxes.forEach((b) => { b.checked = on; });
  });

  $('[data-save]', m).addEventListener('click', () => {
    const fail = (msg) => { err.textContent = msg; err.hidden = false; };
    const email = f.elements.email.value.trim();
    const pass = f.elements.pass.value;
    const refId = role === 'admin' ? '' : f.elements.refId.value;
    const name = role === 'admin' ? f.elements.name.value.trim() : '';
    if (role === 'admin' ? !name : !refId) return fail(role === 'admin' ? t('c.required') : t('acc.personRequired'));
    if (!EMAIL_RE.test(email)) return fail(t('acc.emailInvalid'));
    if (db.accounts.some((o) => o !== a && o.email.toLowerCase() === email.toLowerCase())) return fail(t('acc.emailTaken'));
    if (role !== 'admin') { const taken = accountOf(role, refId); if (taken && taken !== a) return fail(t('acc.personTaken')); }
    if ((isNew || pass) && pass.length < 6) return fail(t('se.passShort'));
    const perms = $$('#accPerms input', m).filter((b) => b.checked).map((b) => b.value);
    const data = { email, role, refId, name, perms, active: self ? true : f.elements.active.checked };
    if (isNew) db.accounts.push({ id: nextId('a'), pass, lastLogin: '', ...data });
    else { Object.assign(a, data); if (pass) a.pass = pass; }
    save();
    closeModal();
    toast(t('c.saved'));
    self ? renderApp() : renderView();
  });
  setTimeout(() => { const first = f.querySelector('select:not(:disabled), input'); if (first) first.focus(); }, 60);
}

function bulkAccounts() {
  formModal({
    title: t('acc.bulkTitle'),
    submitLabel: t('acc.add'),
    intro: `<p class="alert info"><i class="fa-solid fa-circle-info"></i> ${t('acc.bulkHint', { domain: EMAIL_DOMAIN })}</p>`,
    values: { role: 'student', cls: '', pass: '123456' },
    fields: [
      { name: 'role', label: t('acc.role'), type: 'select', options: [{ v: 'student', l: t('role.student') }, { v: 'teacher', l: t('role.teacher') }] },
      { name: 'cls', label: `${t('c.class')} (${t('role.student')})`, type: 'select', options: [{ v: '', l: t('c.all') }, ...sortedClasses().map((c) => ({ v: c.id, l: className(c) }))] },
      { name: 'pass', label: t('acc.pass'), required: true, full: true },
    ],
    onSubmit: (v) => {
      if (v.pass.length < 6) return t('se.passShort');
      const people = v.role === 'teacher' ? db.teachers : db.students.filter((s) => !v.cls || s.classId === v.cls);
      let n = 0;
      people.forEach((p) => {
        if (accountOf(v.role, p.id)) return;
        const email = `${p.code.toLowerCase()}@${EMAIL_DOMAIN}`;
        if (db.accounts.some((a) => a.email.toLowerCase() === email)) return;
        db.accounts.push({ id: nextId('a'), email, pass: v.pass, role: v.role, refId: p.id, name: '', perms: ROLE_PERMS[v.role].slice(), active: true, lastLogin: '' });
        n++;
      });
      save();
      toast(n ? t('acc.bulkDone', { n }) : t('acc.bulkNone'), n ? 'ok' : 'error');
      renderView();
    },
  });
}

// ---------- Tài khoản của tôi (mọi vai trò) ----------
PAGES.profile = () => {
  const u = me();
  const p = myPerson();
  const all = ROLE_PERMS[u.role];
  return `
  ${pageHead(t('pf.title'), '')}
  <div class="settings-grid">
    <div class="card">
      <div class="profile">
        <span class="avatar lg ${p ? p.gender : 'M'}">${esc(initials(displayName(u)))}</span>
        <div><h3>${esc(displayName(u))}</h3><p class="muted">${esc(u.email)}</p><p style="margin-top:6px">${roleBadge(u.role)}</p></div>
      </div>
      <ul class="kv">
        ${p ? `<li><span>${t('c.code')}</span><b>${esc(p.code)}</b></li>` : ''}
        ${u.role === 'student' && p ? `<li><span>${t('c.class')}</span><b>${esc(className(classById(p.classId)))}</b></li>` : ''}
        ${u.role === 'teacher' && p ? `<li><span>${t('c.subject')}</span><b>${esc(loc(subjectById(p.subject)))}</b></li>` : ''}
        <li><span>${t('acc.lastLogin')}</span><b>${fmtDateTime(u.lastLogin) || '—'}</b></li>
      </ul>
      <h4 class="sub-title">${t('acc.perms')}</h4>
      <ul class="perm-view">${all.map((k) => `<li class="${u.perms.includes(k) ? 'on' : ''}"><i class="fa-solid ${u.perms.includes(k) ? 'fa-circle-check' : 'fa-circle-xmark'}"></i> ${t('perm.' + k)}</li>`).join('')}</ul>
    </div>
    <form class="card" id="fPass">
      <div class="card-head"><h3><i class="fa-solid fa-key"></i> ${t('se.password')}</h3></div>
      <div class="form-grid">
        <label class="field full"><span>${t('pf.oldPass')}</span><input name="old" type="password" autocomplete="current-password"></label>
        <label class="field full"><span>${t('se.newPass')}</span><input name="pass" type="password" autocomplete="new-password"></label>
      </div>
      <div class="card-foot"><button class="btn primary" data-act="savePass"><i class="fa-solid fa-check"></i> ${t('c.save')}</button></div>
    </form>
  </div>`;
};

// ---------- Giáo viên: trang chủ, lịch dạy, lớp phụ trách ----------
const lessonRow = (l, withAct) => `<li class="lesson">
  <div class="ls-time"><b>${PERIOD_TIME[l.p - 1]}</b><small>${t('tt.period')} ${l.p}</small></div>
  <div class="ls-main" style="--c:${l.sub ? l.sub.color : '#999'}"><b>${esc(loc(l.sub))}</b><small>${esc(l.label)}</small></div>
  ${withAct || ''}
</li>`;

PAGES.thome = () => {
  const x = myPerson();
  if (!x) return `<div class="card empty-state"><i class="fa-solid fa-link-slash"></i><p>${t('sh.notLinked')}</p></div>`;
  const classes = myClasses();
  const lessons = lessonsOfTeacher(x.id);
  const today = lessons.filter((l) => l.d === todayDow());
  const nStudents = classes.reduce((a, c) => a + studentsOf(c.id).length, 0);
  const tile = (icon, tone, label, value, href) => `<a class="stat ${tone}" href="#${href}"><div class="stat-icon"><i class="fa-solid ${icon}"></i></div><div><span class="stat-label">${label}</span><b class="stat-value">${value}</b></div></a>`;
  return `
  <div class="hero">
    <div><h2>${t('th.hello', { name: esc(x.name) })}</h2><p>${esc(schoolName())} · ${esc(loc(subjectById(x.subject)))} · ${t('d.' + todayDow()) === 'd.' + todayDow() ? '' : t('d.' + todayDow()) + ' · '}${fmtDate(todayIso())}</p></div>
    <div class="hero-flag" aria-hidden="true"><span></span><span></span><span></span></div>
  </div>
  <div class="stats three">
    ${tile('fa-people-roof', 't1', t('th.classes'), classes.length, can('tclasses') ? 'tclasses' : 'thome')}
    ${tile('fa-calendar-week', 't2', t('th.periods'), lessons.length, can('tschedule') ? 'tschedule' : 'thome')}
    ${tile('fa-user-graduate', 't3', t('th.students'), nStudents, can('tclasses') ? 'tclasses' : 'thome')}
  </div>
  <div class="grid-2">
    <div class="card">
      <div class="card-head"><h3><i class="fa-solid fa-clock"></i> ${t('th.today')}</h3>${can('tschedule') ? `<a class="link" href="#tschedule">${t('nav.tschedule')} <i class="fa-solid fa-arrow-right"></i></a>` : ''}</div>
      <ul class="lessons">${today.map((l) => lessonRow({ ...l, label: className(l.c) }, can('attendance') ? `<button class="btn sm primary" data-act="goAttendance" data-id="${l.c.id}"><i class="fa-solid fa-clipboard-check"></i> ${t('nav.attendance')}</button>` : '')).join('') || `<li class="muted empty-line">${t('th.noLesson')}</li>`}</ul>
    </div>
    <div class="card">
      <div class="card-head"><h3><i class="fa-solid fa-people-roof"></i> ${t('th.classes')}</h3></div>
      <ul class="events">${classes.map((c) => `<li><div class="ev-date"><b>${esc(className(c))}</b></div><span class="ev-name">${mySubjects(c.id).map((s) => esc(loc(s))).join(', ') || '—'}${c.homeroomId === x.id ? ` <span class="chip home"><i class="fa-solid fa-star"></i> ${t('th.homeroom')}</span>` : ''}</span><span class="muted">${studentsOf(c.id).length} ${t('c.students')}</span></li>`).join('') || `<li class="muted">${t('th.noClass')}</li>`}</ul>
    </div>
  </div>`;
};

PAGES.tschedule = () => {
  const x = myPerson();
  if (!x) return `<div class="card empty-state"><p>${t('sh.notLinked')}</p></div>`;
  const lessons = lessonsOfTeacher(x.id);
  const at = (d, p) => lessons.filter((l) => l.d === d && l.p === p);
  return `
  ${pageHead(t('nav.tschedule'), `${esc(x.name)} · ${t('th.weekTotal', { n: lessons.length })}`)}
  <div class="card">
    <p class="muted" style="margin-bottom:12px"><i class="fa-regular fa-clock"></i> ${t('tt.hint')}</p>
    <div class="table-wrap"><table class="table tt">
      <thead><tr><th>${t('tt.period')}</th>${DAYS.map((d) => `<th class="${d === todayDow() ? 'today' : ''}">${t('d.' + d)}</th>`).join('')}</tr></thead>
      <tbody>${PERIODS.map((p) => `${p === 5 ? `<tr class="tt-break"><td colspan="${DAYS.length + 1}"><i class="fa-solid fa-bowl-rice"></i> 11:30 – 13:30</td></tr>` : ''}
        <tr><th class="tt-p">${p}<small>${PERIOD_TIME[p - 1]}</small></th>${DAYS.map((d) => `<td class="${d === todayDow() ? 'today' : ''}">${at(d, p).map((l) => `<div class="tt-cell" style="--c:${l.sub.color}"><b>${esc(className(l.c))}</b><small>${esc(loc(l.sub))} · ${t('cl.room')} ${esc(l.c.room || '—')}</small></div>`).join('') || '<span class="muted">—</span>'}</td>`).join('')}</tr>`).join('')}</tbody>
    </table></div>
  </div>`;
};

PAGES.tclasses = () => {
  const x = myPerson();
  const classes = myClasses();
  if (!x || !classes.length) return pageHead(t('nav.tclasses'), '') + noClassCard();
  return `
  ${pageHead(t('nav.tclasses'), `${classes.length} ${t('c.class').toLowerCase()}`)}
  <div class="class-grid">${classes.map((c) => {
    const list = studentsOf(c.id);
    const subs = mySubjects(c.id);
    const n = lessonsOfTeacher(x.id).filter((l) => l.c.id === c.id).length;
    return `<div class="class-card">
      <div class="cc-top"><span class="cc-name">${esc(className(c))}</span>${c.homeroomId === x.id ? `<span class="chip home"><i class="fa-solid fa-star"></i> ${t('th.homeroom')}</span>` : `<span class="chip">${gradeLabel(c.grade)}</span>`}</div>
      <ul class="cc-info">
        <li><i class="fa-solid fa-book"></i> ${t('th.mySubjects')}: <b>${subs.map((s) => esc(loc(s))).join(', ') || '—'}</b></li>
        <li><i class="fa-solid fa-calendar-week"></i> ${t('th.periods')}: <b>${n}</b></li>
        <li><i class="fa-solid fa-door-open"></i> ${t('cl.room')}: ${esc(c.room || '—')}</li>
        <li><i class="fa-solid fa-users"></i> ${t('cl.size')}: <b>${list.length}</b></li>
      </ul>
      <div class="cc-actions">
        <button class="btn sm ghost" data-act="teacherStudentList" data-id="${c.id}"><i class="fa-solid fa-list"></i> ${t('th.studentList')}</button>
        ${can('attendance') ? `<button class="btn sm ghost" data-act="goAttendance" data-id="${c.id}" title="${t('nav.attendance')}" aria-label="${t('nav.attendance')}"><i class="fa-solid fa-clipboard-check"></i></button>` : ''}
        ${can('grades') ? `<button class="btn sm ghost" data-act="goGrades" data-id="${c.id}" title="${t('nav.grades')}" aria-label="${t('nav.grades')}"><i class="fa-solid fa-star-half-stroke"></i></button>` : ''}
      </div>
    </div>`;
  }).join('')}</div>`;
};

function teacherStudentList(c) {
  const list = studentsOf(c.id);
  openModal({
    title: `${t('th.studentList')} · ${className(c)}`,
    wide: true,
    body: `<div class="table-wrap"><table class="table compact">
      <thead><tr><th>#</th><th>${t('c.code')}</th><th>${t('c.name')}</th><th>${t('st.dob')}</th><th>${t('st.parentPhone')}</th><th class="right">${t('at.rate')}</th><th class="right">${t('c.sem1')}</th></tr></thead>
      <tbody>${list.map((s, i) => `<tr><td class="muted">${i + 1}</td><td class="mono">${esc(s.code)}</td><td>${personCell(s, genderLabel(s.gender))}</td><td>${fmtDate(s.dob)}</td><td>${esc(s.parentPhone)}</td><td class="right">${pct(attStats(s.id).rate)}</td><td class="right"><b>${fmtScore(overallAvg(s.id, 1)) || '—'}</b></td></tr>`).join('') || emptyRow(7)}</tbody>
    </table></div>`,
    foot: `<button class="btn ghost" data-close>${t('c.close')}</button>`,
  });
}

// ---------- Học sinh: trang chủ, lớp, lịch học, điểm danh, điểm, học phí ----------
const notLinked = () => `<div class="card empty-state"><i class="fa-solid fa-link-slash"></i><p>${t('sh.notLinked')}</p></div>`;

PAGES.shome = () => {
  const s = myPerson();
  if (!s) return notLinked();
  const c = classById(s.classId);
  const grid = db.timetable[s.classId] || {};
  const today = PERIODS.map((p) => ({ p, sub: subjectById(grid[`${todayDow()}-${p}`]) })).filter((l) => l.sub);
  const avg = overallAvg(s.id, 1);
  const at = attStats(s.id);
  const f = feeInfo(s);
  const tile = (icon, tone, label, value, sub, href) => `<a class="stat ${tone}" href="#${href}"><div class="stat-icon"><i class="fa-solid ${icon}"></i></div><div><span class="stat-label">${label}</span><b class="stat-value">${value}</b>${sub ? `<small>${sub}</small>` : ''}</div></a>`;
  return `
  <div class="hero">
    <div><h2>${t('sh.hello', { name: esc(s.name) })}</h2><p>${esc(schoolName())} · ${esc(className(c))} · ${fmtDate(todayIso())}</p></div>
    <div class="hero-flag" aria-hidden="true"><span></span><span></span><span></span></div>
  </div>
  <div class="stats">
    ${tile('fa-people-roof', 't1', t('c.class'), esc(className(c)), `${t('cl.homeroom')}: ${esc((teacherById(c && c.homeroomId) || {}).name || '—')}`, can('sclass') ? 'sclass' : 'shome')}
    ${can('sgrades') ? tile('fa-star-half-stroke', 't2', `${t('gr.overall')} · ${t('c.sem1')}`, fmtScore(avg) || '—', avg != null ? t(rankOf(avg).k) : '', 'sgrades') : ''}
    ${can('sattendance') ? tile('fa-clipboard-check', 't3', t('at.rate'), pct(at.rate), `${at.total} ${t('at.days').toLowerCase()}`, 'sattendance') : ''}
    ${can('sfees') ? tile('fa-money-bill-wave', 't4', t('nav.fees'), t('fe.st.' + f.status), `${t('fe.remain')}: ${fmtKip(f.remain)}`, 'sfees') : ''}
  </div>
  <div class="card">
    <div class="card-head"><h3><i class="fa-solid fa-clock"></i> ${t('sh.today')}</h3>${can('sschedule') ? `<a class="link" href="#sschedule">${t('nav.sschedule')} <i class="fa-solid fa-arrow-right"></i></a>` : ''}</div>
    <ul class="lessons">${today.map((l) => lessonRow({ ...l, label: (teacherFor(l.sub.id, s.classId) || {}).name || '—' })).join('') || `<li class="muted empty-line">${t('sh.noLesson')}</li>`}</ul>
  </div>`;
};

PAGES.sclass = () => {
  const s = myPerson();
  if (!s) return notLinked();
  const c = classById(s.classId);
  if (!c) return noClassCard();
  const hr = teacherById(c.homeroomId);
  const mates = studentsOf(c.id);
  return `
  ${pageHead(`${t('nav.sclass')}: ${esc(className(c))}`, `${t('cl.grade')} ${gradeLabel(c.grade)} · ${t('cl.room')} ${esc(c.room || '—')} · ${esc(db.settings.year)}`)}
  <div class="grid-2">
    <div class="card">
      <div class="card-head"><h3><i class="fa-solid fa-star"></i> ${t('cl.homeroom')}</h3></div>
      ${hr ? `<div class="person big">${personCell(hr, `${esc(loc(subjectById(hr.subject)))} · ${esc(hr.phone)}`)}</div>` : `<p class="muted">${t('c.none')}</p>`}
      <h4 class="sub-title">${t('cl.teachers')}</h4>
      <div class="table-wrap"><table class="table compact">
        <thead><tr><th>${t('c.subject')}</th><th>${t('role.teacher')}</th><th>${t('c.email')}</th></tr></thead>
        <tbody>${SUBJECTS.map((sub) => { const x = teacherFor(sub.id, c.id); return `<tr><td><span class="dot" style="--c:${sub.color}"></span>${esc(loc(sub))}</td><td>${x ? esc(x.name) : '<span class="muted">—</span>'}</td><td class="muted">${x ? esc(x.email) : ''}</td></tr>`; }).join('')}</tbody>
      </table></div>
    </div>
    <div class="card">
      <div class="card-head"><h3><i class="fa-solid fa-users"></i> ${t('sh.classmates')}</h3><span class="muted">${mates.length} ${t('c.students')}</span></div>
      <ul class="mates">${mates.map((m) => `<li class="${m.id === s.id ? 'me' : ''}">${personCell(m, esc(m.code))}</li>`).join('')}</ul>
    </div>
  </div>`;
};

PAGES.sschedule = () => {
  const s = myPerson();
  if (!s) return notLinked();
  const c = classById(s.classId);
  return `
  ${pageHead(t('nav.sschedule'), `${esc(className(c))} · ${esc(db.settings.year)}`)}
  <div class="card">
    <p class="muted" style="margin-bottom:12px"><i class="fa-regular fa-clock"></i> ${t('tt.hint')}</p>
    <div class="table-wrap">${timetableTable(s.classId, false)}</div>
  </div>`;
};

PAGES.sattendance = () => {
  const s = myPerson();
  if (!s) return notLinked();
  const st = attStats(s.id);
  const rows = Object.keys(db.attendance)
    .filter((k) => db.attendance[k][s.id])
    .map((k) => ({ date: k.split('|')[1], v: db.attendance[k][s.id] }))
    .sort((a, b) => b.date.localeCompare(a.date));
  const byK = Object.fromEntries(ATT.map((a) => [a.k, a]));
  return `
  ${pageHead(t('nav.sattendance'), `${esc(s.name)} · ${esc(className(classById(s.classId)))}`)}
  <div class="stats">
    <div class="stat t1"><div class="stat-icon"><i class="fa-solid fa-percent"></i></div><div><span class="stat-label">${t('at.rate')}</span><b class="stat-value">${pct(st.rate)}</b><small>${st.total} ${t('at.days').toLowerCase()}</small></div></div>
    ${ATT.slice(1).map((a, i) => `<div class="stat t${[2, 3, 4][i]}"><div class="stat-icon"><i class="fa-solid ${a.i}"></i></div><div><span class="stat-label">${t(a.l)}</span><b class="stat-value">${st[a.k]}</b></div></div>`).join('')}
  </div>
  <div class="card">
    <div class="table-wrap"><table class="table">
      <thead><tr><th>${t('c.date')}</th><th>${t('c.status')}</th></tr></thead>
      <tbody>${rows.map((r) => { const a = byK[r.v]; const wd = new Date(r.date + 'T00:00:00').getDay(); return `<tr><td>${I18N[LANG]['d.' + wd] ? t('d.' + wd) + ', ' : ''}${fmtDate(r.date)}</td><td><span class="badge ${a.c}"><i class="fa-solid ${a.i}"></i> ${t(a.l)}</span></td></tr>`; }).join('') || `<tr><td colspan="2" class="empty">${t('sh.noRecords')}</td></tr>`}</tbody>
    </table></div>
  </div>`;
};

PAGES.sgrades = () => {
  const s = myPerson();
  if (!s) return notLinked();
  const sem = ui.sg.sem;
  const all = overallAvg(s.id, sem);
  return `
  ${pageHead(t('nav.sgrades'), `${esc(s.name)} · ${esc(className(classById(s.classId)))}`)}
  <div class="card">
    <div class="toolbar">
      <div class="seg" role="group">${['1', '2'].map((v) => `<button data-act="sgSem" data-v="${v}" class="${sem === v ? 'on' : ''}">${t('c.sem' + v)}</button>`).join('')}</div>
      <span class="stat-chip"><b>${fmtScore(all) || '—'}</b> ${t('gr.overall')}</span> ${rankBadge(all)}
    </div>
    <div class="table-wrap"><table class="table">
      <thead><tr><th>${t('c.subject')}</th>${PARTS.map((p) => `<th class="center">${t(PART_LABEL[p])}<small class="block muted">×${WEIGHT[p]}</small></th>`).join('')}<th class="center">${t('gr.avg')}</th><th>${t('gr.rank')}</th></tr></thead>
      <tbody>${SUBJECTS.map((sub) => {
        const g = gradeRec(s.id, sub.id, sem) || {};
        const a = avgOf(g);
        return `<tr><td><span class="dot" style="--c:${sub.color}"></span><b>${esc(loc(sub))}</b><small class="block muted">${esc((teacherFor(sub.id, s.classId) || {}).name || '')}</small></td>
          ${PARTS.map((p) => `<td class="center ${g[p] != null && g[p] < 5 ? 'low' : ''}">${g[p] ?? '<span class="muted">—</span>'}</td>`).join('')}
          <td class="center"><b>${fmtScore(a) || '—'}</b></td><td>${rankBadge(a)}</td></tr>`;
      }).join('')}
      <tr class="total-row"><td>${t('gr.overall')}</td><td colspan="4"></td><td class="center">${fmtScore(all) || '—'}</td><td>${rankBadge(all)}</td></tr></tbody>
    </table></div>
    <p class="note"><i class="fa-solid fa-circle-info"></i> ${t('gr.formula')}</p>
  </div>`;
};

PAGES.sfees = () => {
  const s = myPerson();
  if (!s) return notLinked();
  const f = feeInfo(s);
  const list = db.payments.filter((p) => p.studentId === s.id).sort((a, b) => b.date.localeCompare(a.date));
  const p = f.req ? Math.round((Math.min(f.paid, f.req) / f.req) * 100) : 0;
  return `
  ${pageHead(t('nav.sfees'), `${t('se.year')} ${esc(db.settings.year)}`)}
  <div class="grid-2">
    <div class="card">
      <div class="card-head"><h3>${t('st.feeSummary')}</h3>${feeBadge(f.status)}</div>
      <div class="meter-big"><b>${p}%</b><span class="muted">${fmtKip(f.paid)} / ${fmtKip(f.req)}</span></div>
      <div class="meter" role="progressbar" aria-valuenow="${p}" aria-valuemin="0" aria-valuemax="100"><div style="width:${p}%"></div></div>
      <ul class="kv" style="margin-top:16px">
        <li><span>${t('fe.required')}</span><b>${fmtKip(f.req)}</b></li>
        <li><span>${t('fe.paid')}</span><b>${fmtKip(f.paid)}</b></li>
        <li><span>${t('fe.remain')}</span><b class="${f.remain ? 'debt' : ''}">${fmtKip(f.remain)}</b></li>
      </ul>
    </div>
    <div class="card">
      <div class="card-head"><h3>${t('fe.history')}</h3></div>
      <div class="table-wrap"><table class="table compact">
        <thead><tr><th>${t('fe.receipt')}</th><th>${t('c.date')}</th><th class="right">${t('fe.amount')}</th><th></th></tr></thead>
        <tbody>${list.map((x) => `<tr><td class="mono">${esc(x.no)}</td><td>${fmtDate(x.date)}</td><td class="right num"><b>${fmtKip(x.amount)}</b></td><td class="right"><button class="icon-btn sm" data-act="openReceipt" data-id="${x.id}" title="${t('fe.receipt')}" aria-label="${t('fe.receipt')}"><i class="fa-regular fa-file-lines"></i></button></td></tr>`).join('') || emptyRow(4)}</tbody>
      </table></div>
    </div>
  </div>`;
};

const ACT = {
  openSide: () => document.body.classList.add('side-open'),
  closeSide: () => document.body.classList.remove('side-open'),
  setLang: (el) => {
    LANG = prefs.lang = el.dataset.v;
    savePrefs();
    applyTheme();
    isLoggedIn() ? renderApp() : renderLogin();
  },
  toggleTheme: () => { prefs.theme = isDark() ? 'light' : 'dark'; savePrefs(); applyTheme(); renderApp(); },
  setTheme: (el) => { prefs.theme = el.dataset.v; savePrefs(); applyTheme(); renderApp(); },
  logout: () => { setAuth(''); closeModal(); history.replaceState(null, '', location.pathname); renderLogin(); },
  fillDemo: (el) => {
    const f = $('#loginForm');
    f.elements.user.value = el.dataset.e;
    f.elements.pass.value = el.dataset.p;
    f.requestSubmit ? f.requestSubmit() : f.dispatchEvent(new Event('submit', { cancelable: true }));
  },

  // Sự kiện
  addEvent: () => formModal({
    title: t('dash.addEvent'),
    values: { date: todayIso() },
    fields: [{ name: 'date', label: t('c.date'), type: 'date', required: true }, { name: 'name', label: t('dash.eventName'), required: true, full: true }],
    onSubmit: (v) => { db.events.push({ id: nextId('e'), ...v }); save(); toast(t('c.saved')); renderView(); },
  }),
  delEvent: (el) => {
    const e = db.events.find((x) => x.id === el.dataset.id);
    if (e) confirmBox(t('c.confirmDelete', { name: e.name }), () => { db.events = db.events.filter((x) => x !== e); save(); renderView(); });
  },

  // Học sinh
  addStudent: () => studentForm(null),
  editStudent: (el) => { const s = studentById(el.dataset.id); if (s) studentForm(s); },
  viewStudent: (el) => { const s = studentById(el.dataset.id); if (s) studentDetail(s); },
  delStudent: (el) => { const s = studentById(el.dataset.id); if (s) deleteStudent(s); },
  stPage: (el) => { ui.st.page = Number(el.dataset.p); refreshStudents(); },
  exportStudents: () => downloadCsv('hoc-sinh.csv', [
    [t('c.code'), t('c.name'), t('c.gender'), t('st.dob'), t('c.class'), t('st.ethnic'), t('st.province'), t('st.address'), t('st.parent'), t('st.parentPhone')],
    ...filteredStudents().map((s) => [s.code, s.name, genderLabel(s.gender), fmtDate(s.dob), className(classById(s.classId)), loc(ETHNICS[s.ethnic]), loc(PROVINCES[s.province]), s.address, s.parent, s.parentPhone]),
  ]),

  // Giáo viên
  addTeacher: () => teacherForm(null),
  editTeacher: (el) => { const x = teacherById(el.dataset.id); if (x) teacherForm(x); },
  delTeacher: (el) => {
    const x = teacherById(el.dataset.id);
    if (!x) return;
    confirmBox(t('c.confirmDelete', { name: x.name }), () => {
      db.teachers = db.teachers.filter((o) => o !== x);
      db.accounts = db.accounts.filter((a) => !(a.role === 'teacher' && a.refId === x.id));
      db.classes.forEach((c) => {
        if (c.homeroomId === x.id) c.homeroomId = '';
        Object.keys(c.teachers || {}).forEach((k) => { if (c.teachers[k] === x.id) delete c.teachers[k]; });
      });
      save(); toast(t('c.deleted')); renderView();
    });
  },
  exportTeachers: () => downloadCsv('giao-vien.csv', [
    [t('c.code'), t('c.name'), t('c.gender'), t('c.subject'), t('tc.degree'), t('c.phone'), t('c.email'), t('tc.startYear')],
    ...db.teachers.map((x) => [x.code, x.name, genderLabel(x.gender), loc(subjectById(x.subject)), loc(DEGREES[x.degree]), x.phone, x.email, x.startYear]),
  ]),

  // Lớp học
  addClass: () => classForm(null),
  editClass: (el) => { const c = classById(el.dataset.id); if (c) classForm(c); },
  delClass: (el) => {
    const c = classById(el.dataset.id);
    if (!c) return;
    if (studentsOf(c.id).length) return toast(t('cl.hasStudents'), 'error');
    confirmBox(t('c.confirmDelete', { name: className(c) }), () => {
      db.classes = db.classes.filter((o) => o !== c);
      delete db.timetable[c.id];
      Object.keys(db.attendance).forEach((k) => { if (k.startsWith(c.id + '|')) delete db.attendance[k]; });
      save(); toast(t('c.deleted')); renderView();
    });
  },
  classStudents: (el) => { ui.st.cls = el.dataset.id; ui.st.page = 1; location.hash = '#students'; },
  classTimetable: (el) => { ui.tt.cls = el.dataset.id; location.hash = '#timetable'; },

  // Điểm
  grMode: (el) => { ui.gr.mode = el.dataset.v; renderView(); },
  exportSummary: () => {
    const c = classById(ui.gr.cls);
    downloadCsv(`tong-ket-${c ? c.name.replace('/', '-') : ''}-hk${ui.gr.sem}.csv`, [
      [t('c.code'), t('c.name'), ...SUBJECTS.map(loc), t('gr.overall'), t('gr.rank'), t('gr.position')],
      ...summaryData().map((r) => [r.s.code, r.s.name, ...r.subs.map(fmtScore), fmtScore(r.all), r.all == null ? '' : t(rankOf(r.all).k), r.pos || '']),
    ]);
  },

  // Điểm danh
  mark: (el) => {
    if (!can('attendance') || !myClasses().some((c) => c.id === ui.at.cls)) return toast(t('c.noPerm'), 'error');
    const key = `${ui.at.cls}|${ui.at.date}`;
    (db.attendance[key] = db.attendance[key] || {})[el.dataset.sid] = el.dataset.v;
    save();
    $('#atBody').innerHTML = attBody();
    const again = $(`#atBody [data-sid="${el.dataset.sid}"][data-v="${el.dataset.v}"]`);
    if (again) again.focus();
  },
  allPresent: () => {
    if (!can('attendance') || !myClasses().some((c) => c.id === ui.at.cls)) return toast(t('c.noPerm'), 'error');
    const rec = {};
    studentsOf(ui.at.cls).forEach((s) => { rec[s.id] = 'P'; });
    db.attendance[`${ui.at.cls}|${ui.at.date}`] = rec;
    save(); toast(t('c.saved'));
    $('#atBody').innerHTML = attBody();
  },

  // Học phí
  fePage: (el) => { ui.fe.page = Number(el.dataset.p); $('#feList').innerHTML = feeList(); },
  collectFee: (el) => { const s = studentById(el.dataset.id); if (s) collectFee(s); },
  feeHistory: (el) => { const s = studentById(el.dataset.id); if (s) feeHistory(s); },
  openReceipt: (el) => { const p = db.payments.find((x) => x.id === el.dataset.id); if (p) showReceipt(p); },
  printReceipt: (el) => { const p = db.payments.find((x) => x.id === el.dataset.id); if (p) printHtml(receiptHtml(p)); },
  delPayment: (el) => {
    const p = db.payments.find((x) => x.id === el.dataset.id);
    if (!p) return;
    const s = studentById(p.studentId);
    confirmBox(t('c.confirmDelete', { name: `${p.no} · ${fmtKip(p.amount)}` }), () => {
      db.payments = db.payments.filter((x) => x !== p);
      save(); toast(t('c.deleted')); renderView();
      if (s) feeHistory(s);
    });
  },
  exportFees: () => downloadCsv('hoc-phi.csv', [
    [t('c.code'), t('c.name'), t('c.class'), t('fe.required'), t('fe.paid'), t('fe.remain'), t('c.status')],
    ...filteredFees().map(({ s, f }) => [s.code, s.name, className(classById(s.classId)), f.req, f.paid, f.remain, t('fe.st.' + f.status)]),
  ]),

  // Thời khóa biểu
  ttEdit: () => { ui.tt.edit = !ui.tt.edit; if (!ui.tt.edit) toast(t('c.saved')); renderView(); },
  printTimetable: () => {
    const c = classById(ui.tt.cls);
    printHtml(`<div class="print-tt"><h2>${esc(schoolName())}</h2><h3>${t('tt.title')} · ${esc(className(c))} · ${esc(db.settings.year)}</h3>${timetableTable(ui.tt.cls, false)}</div>`);
  },

  // Cài đặt
  saveSchool: () => {
    const f = $('#fSchool').elements;
    ['nameVi', 'nameLo', 'address', 'principal', 'phone', 'year'].forEach((k) => { db.settings[k] = f[k].value.trim(); });
    if (!db.settings.nameVi) db.settings.nameVi = 'School';
    save(); toast(t('c.saved')); renderApp();
  },
  saveFees: () => {
    const f = $('#fFee').elements;
    const lo = Number(f.feeLower.value), up = Number(f.feeUpper.value);
    if (!(lo >= 0) || !(up >= 0) || f.feeLower.value === '' || f.feeUpper.value === '') return toast(t('fe.invalidAmount'), 'error');
    db.settings.feeLower = Math.round(lo);
    db.settings.feeUpper = Math.round(up);
    save(); toast(t('c.saved')); renderView();
  },
  savePass: () => {
    const f = $('#fPass').elements;
    const u = me();
    if (f.old.value !== u.pass) return toast(t('pf.wrongOld'), 'error');
    if (f.pass.value.length < 6) return toast(t('se.passShort'), 'error');
    u.pass = f.pass.value;
    save(); toast(t('se.passChanged')); renderView();
  },
  backup: () => download(`backup-truong-hoc-${todayIso()}.json`, JSON.stringify(db, null, 2), 'application/json'),
  resetData: () => confirmBox(t('se.resetConfirm'), () => { db = createSeed(); save(); toast(t('c.saved')); renderApp(); }),
};

const CHANGE = {
  stClass: (el) => { ui.st.cls = el.value; ui.st.page = 1; refreshStudents(); },
  stGender: (el) => { ui.st.gender = el.value; ui.st.page = 1; refreshStudents(); },
  tcSub: (el) => { ui.tc.sub = el.value; $('#tcBody').innerHTML = teacherRows(); },
  grClass: (el) => { ui.gr.cls = el.value; renderView(); },
  grSub: (el) => { ui.gr.sub = el.value; renderView(); },
  grSem: (el) => { ui.gr.sem = el.value; renderView(); },
  score: (el) => {
    if (!can('grades') || !mySubjects(ui.gr.cls).some((s) => s.id === ui.gr.sub)) return toast(t('c.noPerm'), 'error');
    const tr = el.closest('tr');
    const key = `${tr.dataset.sid}|${ui.gr.sub}|${ui.gr.sem}`;
    const raw = el.value.trim().replace(',', '.');
    let v = null;
    if (raw !== '') {
      v = Number(raw);
      if (!isFinite(v) || v < 0 || v > 10) { el.classList.add('invalid'); return toast(t('gr.invalid'), 'error'); }
      v = Math.round(v * 100) / 100;
    }
    el.classList.remove('invalid');
    const g = db.grades[key] || { oral: null, t15: null, mid: null, final: null };
    g[el.dataset.part] = v;
    db.grades[key] = g;
    save();
    const a = avgOf(g);
    $('.avg', tr).innerHTML = `<b>${fmtScore(a)}</b>`;
    $('.rank', tr).innerHTML = rankBadge(a);
    $('#grStats').innerHTML = gradeStats();
    el.classList.add('flash');
    setTimeout(() => el.classList.remove('flash'), 600);
  },
  atClass: (el) => { ui.at.cls = el.value; renderView(); },
  atDate: (el) => { if (el.value) { ui.at.date = el.value; renderView(); } },
  feClass: (el) => { ui.fe.cls = el.value; ui.fe.page = 1; $('#feList').innerHTML = feeList(); },
  feStatus: (el) => { ui.fe.status = el.value; ui.fe.page = 1; $('#feList').innerHTML = feeList(); },
  ttClass: (el) => { ui.tt.cls = el.value; renderView(); },
  ttCell: (el) => {
    const grid = (db.timetable[ui.tt.cls] = db.timetable[ui.tt.cls] || {});
    grid[el.dataset.slot] = el.value;
    save();
  },
  restore: (el) => {
    const file = el.files && el.files[0];
    if (!file) return;
    const r = new FileReader();
    r.onload = () => {
      try {
        const d = JSON.parse(r.result);
        if (!validDb(d)) throw new Error('bad');
        db = migrate(d);
        // Nếu file khôi phục không có tài khoản đang đăng nhập → phải đăng nhập lại
        if (!me()) setAuth('');
        save(); toast(t('se.restored')); renderApp();
      } catch (e) { toast(t('se.badFile'), 'error'); }
    };
    r.readAsText(file);
  },
};

const INPUT = {
  stSearch: (el) => { ui.st.q = el.value; ui.st.page = 1; refreshStudents(); },
  tcSearch: (el) => { ui.tc.q = el.value; $('#tcBody').innerHTML = teacherRows(); },
  feSearch: (el) => { ui.fe.q = el.value; ui.fe.page = 1; $('#feList').innerHTML = feeList(); },
};

document.addEventListener('click', (e) => {
  const el = e.target.closest('[data-act]');
  if (!el || el.disabled) return;
  const fn = ACT[el.dataset.act];
  if (fn) { e.preventDefault(); fn(el, e); }
});
document.addEventListener('change', (e) => {
  const el = e.target.closest('[data-change]');
  if (el && CHANGE[el.dataset.change]) CHANGE[el.dataset.change](el);
});
document.addEventListener('input', (e) => {
  const el = e.target.closest('[data-input]');
  if (el && INPUT[el.dataset.input]) INPUT[el.dataset.input](el);
});
// Tài khoản, phân công, trang giáo viên / học sinh
Object.assign(ACT, {
  newAccount: () => accountForm(null, { role: ui.acc.role || 'teacher' }),
  newAccountFor: (el) => accountForm(null, { role: el.dataset.role, refId: el.dataset.ref }),
  editAccount: (el) => { const a = db.accounts.find((x) => x.id === el.dataset.id); if (a) accountForm(a); },
  bulkAccounts: () => bulkAccounts(),
  accPage: (el) => { ui.acc.page = Number(el.dataset.p); $('#accList').innerHTML = accountList(); },
  toggleLock: (el) => {
    const a = db.accounts.find((x) => x.id === el.dataset.id);
    if (!a) return;
    if (a.id === me().id) return toast(t('acc.self'), 'error');
    a.active = !a.active;
    save(); toast(t(a.active ? 'acc.unlock' : 'acc.lock') + ': ' + a.email); renderView();
  },
  resetPass: (el) => {
    const a = db.accounts.find((x) => x.id === el.dataset.id);
    if (!a) return;
    formModal({
      title: `${t('acc.resetPass')} · ${a.email}`,
      values: { pass: String(Math.floor(100000 + Math.random() * 900000)) },
      fields: [{ name: 'pass', label: t('se.newPass'), required: true, full: true }],
      onSubmit: (v) => {
        if (v.pass.length < 6) return t('se.passShort');
        a.pass = v.pass;
        save(); toast(t('acc.resetDone', { p: v.pass }));
      },
    });
  },
  delAccount: (el) => {
    const a = db.accounts.find((x) => x.id === el.dataset.id);
    if (!a) return;
    if (a.id === me().id) return toast(t('acc.self'), 'error');
    confirmBox(t('c.confirmDelete', { name: a.email }), () => {
      db.accounts = db.accounts.filter((x) => x !== a);
      save(); toast(t('c.deleted')); renderView();
    });
  },
  assignTeachers: (el) => { const c = classById(el.dataset.id); if (c) assignTeachers(c); },
  goAttendance: (el) => { ui.at.cls = el.dataset.id; ui.at.date = todayIso(); location.hash = '#attendance'; },
  goGrades: (el) => { ui.gr.cls = el.dataset.id; ui.gr.mode = 'entry'; location.hash = '#grades'; },
  teacherStudentList: (el) => { const c = classById(el.dataset.id); if (c) teacherStudentList(c); },
  sgSem: (el) => { ui.sg.sem = el.dataset.v; renderView(); },
});
CHANGE.accRole = (el) => { ui.acc.role = el.value; ui.acc.page = 1; $('#accList').innerHTML = accountList(); };
INPUT.accSearch = (el) => { ui.acc.q = el.value; ui.acc.page = 1; $('#accList').innerHTML = accountList(); };

// Không có form nào gửi dữ liệu lên server — chặn reload trang khi nhấn Enter
document.addEventListener('submit', (e) => e.preventDefault());
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') { closeModal(); document.body.classList.remove('side-open'); }
  // Nhập điểm: Enter chuyển xuống học sinh kế tiếp cùng cột
  if (e.key === 'Enter' && e.target.classList.contains('score')) {
    e.preventDefault();
    e.target.blur();
    const tr = e.target.closest('tr').nextElementSibling;
    const next = tr && tr.querySelector(`.score[data-part="${e.target.dataset.part}"]`);
    if (next) { next.focus(); next.select(); }
  }
});
window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if (!prefs.theme && isLoggedIn()) renderApp(); });

// ===== Khởi động =====
applyTheme();
isLoggedIn() ? renderApp() : renderLogin();
